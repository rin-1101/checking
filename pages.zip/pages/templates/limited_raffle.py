"""Prize-limited raffles with durable winner exclusion and prize re-entry rules."""

import csv
import io
import os
import random
import time
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone

import dash
import yaml
from dash import Input, Output, State, callback, dcc, html
from dash.exceptions import PreventUpdate

from .simple_raffle import SimpleRafflePage
from .modules.raffle.draw import parse_entry_count


@contextmanager
def event_lock(history_path):
    """Serialize draws and history resets across app workers."""
    lock_path = history_path.with_suffix(history_path.suffix + ".lock")
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    with lock_path.open("a+b") as file:
        file.seek(0, os.SEEK_END)
        if file.tell() == 0:
            file.write(b"0")
            file.flush()
        deadline = time.monotonic() + 10
        while True:
            try:
                file.seek(0)
                if os.name == "nt":
                    import msvcrt
                    msvcrt.locking(file.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except OSError:
                if time.monotonic() >= deadline:
                    raise TimeoutError("Another raffle action is in progress. Try again.")
                time.sleep(0.05)
        try:
            yield
        finally:
            file.seek(0)
            if os.name == "nt":
                msvcrt.locking(file.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(file.fileno(), fcntl.LOCK_UN)


class LimitedRafflePage(SimpleRafflePage):
    def __init__(self, config, prize_pool, selectable_draws=False, **kwargs):
        super().__init__(config, **kwargs)
        self.prize_pool = prize_pool
        self.selectable_draws = selectable_draws

    def _pool(self):
        with self.config.prize_options_path.open(encoding="utf-8") as file:
            prizes = yaml.safe_load(file)[self.prize_pool]
        if not prizes or any(
            not isinstance(p.get("name"), str)
            or not p["name"].strip()
            or type(p.get("limit")) is not int
            or p["limit"] <= 0
            for p in prizes
        ):
            raise ValueError("Invalid raffle prize configuration.")
        if self.selectable_draws and any(
            type(p.get("batch_size")) is not int
            or p["batch_size"] <= 0
            or p["limit"] % p["batch_size"]
            for p in prizes
        ):
            raise ValueError("Each prize limit must contain complete draw batches.")
        for index, prize in enumerate(prizes):
            allowed = prize.get("eligible_previous_prizes", [])
            earlier_names = {name for p in prizes[:index]
                             for name in (p["name"], *p.get("aliases", []))}
            if (not isinstance(allowed, list)
                    or any(not isinstance(name, str) or name not in earlier_names
                           for name in allowed)
                    or (allowed and not self.selectable_draws)):
                raise ValueError("Prize re-entry must reference earlier selectable prizes.")
        return prizes

    def _prize_options(self):
        return [p["name"] for p in self._pool()]

    def _prize_category(self, prize_name, pool=None):
        for prize in self._pool() if pool is None else pool:
            if prize_name in {prize["name"], *prize.get("aliases", [])}:
                return prize.get("category", "")
        return ""

    def _prize_headers(self):
        return [html.Th("Prize Category", scope="col"), *super()._prize_headers()]

    def _prize_cells(self, record):
        return [
            html.Td(self._prize_category(record.get("prize", ""))),
            *super()._prize_cells(record),
        ]

    @staticmethod
    def _count(prize, records):
        names = {prize["name"], *prize.get("aliases", [])}
        return sum(record.get("prize") in names for record in records)

    def _draw_slots(self, pool, records, selected_prize=None):
        if not self.selectable_draws:
            return [p["name"] for p in pool
                    for _ in range(max(0, p["limit"] - self._count(p, records)))]
        for index, prize in enumerate(pool):
            if selected_prize != prize["name"]:
                continue
            if any(self._count(p, records) < p["limit"] for p in pool[:index]):
                raise ValueError("Complete the earlier prize draws before this draw.")
            remaining = prize["limit"] - self._count(prize, records)
            if remaining <= 0:
                raise ValueError("All {} winners have been drawn. Select another draw type."
                                 .format(prize.get("category", prize["name"])))
            if remaining < prize["batch_size"]:
                raise ValueError("The remaining prize slots do not form a complete draw.")
            return [prize["name"]] * prize["batch_size"]
        raise ValueError("Select a draw type from the dropdown.")

    def prize_status(self, selected_prize=None):
        try:
            records = self.history.read()
            pool = self._pool()
            remaining = sum(max(0, p["limit"] - self._count(p, records)) for p in pool)
            summary = html.Ul([
                html.Li([
                    *([html.Strong(p["category"]), " "] if p.get("category") else []),
                    "{}: {}/{} winners".format(
                        p["name"], self._count(p, records), p["limit"]
                    ),
                    *([" ({}/{} draws)".format(
                        self._count(p, records) // p["batch_size"],
                        p["limit"] // p["batch_size"],
                    )] if self.selectable_draws else []),
                ]) for p in pool
            ])
            if self.selectable_draws and remaining:
                try:
                    slots = self._draw_slots(pool, records, selected_prize)
                except ValueError as error:
                    return True, html.Div([summary, html.P(str(error))])
                return False, html.Div([
                    summary,
                    html.P("Draw Raffle will draw {} winner(s) for the selected prize."
                           .format(len(slots))),
                ])
            message = (
                "All prizes have been drawn. Reset to start a new round."
                if not remaining else
                "Draw Raffle will draw all {} remaining winners.".format(remaining)
            )
            return not remaining, html.Div([summary, html.P(message)])
        except Exception:
            return True, "Prize configuration or winner history is unavailable."

    def _action_buttons(self):
        buttons = super()._action_buttons()
        buttons = [b for b in buttons if b.id != self.id("reset-button")]
        for button in buttons:
            if button.id == self.id("reset-history-button"):
                button.children = "Reset"
        buttons[0].disabled = True
        return buttons

    def _prize_control(self):
        controls = []
        if self.selectable_draws:
            pool = self._pool()
            controls.append(dcc.Dropdown(
                id=self.id("prize-input"),
                options=[{"label": p.get("draw_label", p["name"]), "value": p["name"]}
                         for p in pool],
                value=pool[0]["name"],
                clearable=False,
                className="simple-raffle-prize-dropdown",
            ))
        return html.Div([*controls,
            html.Div(id=self.id("prize-status"), **{"aria-live": "polite"}),
            dcc.Interval(id=self.id("prize-refresh"), interval=2000),
        ])

    def draw_all(self, selected_prize=None):
        cfg = self.config
        with event_lock(cfg.history_file_path):
            records = self.history.read()
            pool = self._pool()
            slots = self._draw_slots(pool, records, selected_prize)
            if not slots:
                raise ValueError("All prizes have been drawn. Reset to start a new round.")

            with cfg.entries_csv_path.open(newline="", encoding="utf-8-sig") as file:
                reader = csv.DictReader(file)
                fields = reader.fieldnames
                if not {"UniversalPlayerID", "Name", "Entries"}.issubset(fields or []):
                    raise ValueError("Raffle entries are missing required columns.")
                rows = list(reader)
            if "won_entries" not in fields:
                fields.append("won_entries")
            normalize = lambda value: str(value).strip().casefold()
            allowed_names = {name for p in pool if p["name"] in slots
                             for name in p.get("eligible_previous_prizes", [])}
            allowed_names = {name for p in pool
                             if allowed_names.intersection({p["name"], *p.get("aliases", [])})
                             for name in (p["name"], *p.get("aliases", []))}
            repeat_eligible = {normalize(r["uid"]) for r in records
                               if r.get("prize") in allowed_names}
            repeat_eligible.difference_update(
                normalize(r["uid"]) for r in records
                if r.get("prize") not in allowed_names
            )
            excluded = {normalize(r["uid"]) for r in records}
            excluded.update(normalize(uid) for uid in
                            self.raffle.winner_sets.winner_ids(cfg.event_name))
            excluded.difference_update(repeat_eligible)
            for row in rows:
                entries = parse_entry_count(row["Entries"], "Entries")
                used = parse_entry_count(row.get("won_entries"), "won_entries", allow_blank=True)
                row["Entries"] = entries
                row["won_entries"] = used
                if entries < 0 or used < 0 or used > entries:
                    raise ValueError("Invalid raffle entry counts.")
                if used and normalize(row["UniversalPlayerID"]) not in repeat_eligible:
                    excluded.add(normalize(row["UniversalPlayerID"]))
            eligible = [r for r in rows if int(r["Entries"]) > 0
                        and normalize(r["UniversalPlayerID"]) not in excluded]
            unique_count = len({normalize(r["UniversalPlayerID"]) for r in eligible})
            if unique_count < len(slots):
                raise ValueError(
                    "Need {} unique eligible patrons, but only {} are available. No winners were drawn."
                    .format(len(slots), unique_count)
                )
            winners = []
            for prize_name in slots:
                winner = random.choices(
                    eligible, weights=[int(r["Entries"]) for r in eligible]
                )[0]
                winners.append((winner["UniversalPlayerID"].strip(),
                                winner["Name"].strip(), prize_name))
                # Re-entry uses the original entry weight. A patron with one
                # ticket can win both tiers; consumed tickets stay bounded.
                winner["won_entries"] = min(
                    int(winner["Entries"]), int(winner.get("won_entries") or 0) + 1
                )
                winner_id = normalize(winner["UniversalPlayerID"])
                eligible = [r for r in eligible
                            if normalize(r["UniversalPlayerID"]) != winner_id]

            # Save the entire batch before updating entry bookkeeping. History
            # remains authoritative if a later write fails.
            added = self.history.add_many(winners)
            warning = None
            try:
                temp = cfg.entries_csv_path.with_suffix(".csv.tmp")
                with temp.open("w", newline="", encoding="utf-8") as file:
                    writer = csv.DictWriter(file, fieldnames=fields)
                    writer.writeheader()
                    writer.writerows(rows)
                temp.replace(cfg.entries_csv_path)
                for record in added:
                    self.raffle.winner_sets.add(cfg.event_name, record["uid"], record["name"])
            except Exception:
                if cfg.logger:
                    cfg.logger.exception("Winner saved; raffle entry bookkeeping failed")
                warning = "Winners saved, but entry bookkeeping failed. Contact support before resetting."
            return added, warning

    def register_callbacks(self):
        id_ = self.id

        status_args = [
            Output(id_("draw-button"), "disabled"),
            Output(id_("prize-status"), "children"),
            Input(id_("history-body"), "children"),
            Input(id_("prize-refresh"), "n_intervals"),
        ]
        if self.selectable_draws:
            status_args.append(Input(id_("prize-input"), "value"))

        @callback(*status_args)
        def update_status(_history, _interval, selected_prize=None):
            return self.prize_status(selected_prize)

        @callback(
            Output(id_("history-body"), "children"),
            Input(id_("prize-refresh"), "n_intervals"),
            Input(id_("result-label"), "children"),
        )
        def refresh_history(_interval, _result_label):
            # Each browser reads the shared file; polling never draws or resets.
            return self._history_rows()

        action_args = [
            Output(id_("result-label"), "children"),
            Output(id_("winner-id"), "children"),
            Output(id_("winner-name"), "children"),
            Output(id_("result"), "className"),
            Input(id_("draw-button"), "n_clicks"),
            Input(id_("reset-history-button"), "n_clicks"),
        ]
        if self.selectable_draws:
            action_args.append(State(id_("prize-input"), "value"))

        @callback(*action_args, prevent_initial_call=True)
        def handle_action(draw_clicks, reset_clicks, selected_prize=None):
            trigger = dash.ctx.triggered_id
            if not ((trigger == id_("draw-button") and draw_clicks)
                    or (trigger == id_("reset-history-button") and reset_clicks)):
                raise PreventUpdate
            try:
                if trigger == id_("reset-history-button"):
                    with event_lock(self.config.history_file_path):
                        # Keep history until entry/set reset succeeds so a failed
                        # reset cannot accidentally reopen prize slots.
                        self.raffle.reset_entries(self.config.event_name)
                        self.history.clear()
                    return ("Raffle reset", "-", "Entries restored. Winner history and prize limits cleared. All patrons are eligible again.",
                            "simple-raffle-result is-reset")
                winners, warning = self.draw_all(selected_prize)
                message = ("Selected draw finished. See the winners and their prizes below."
                           if self.selectable_draws else
                           "All prizes drawn. See the winners and their prizes below.")
                return ("Draw complete" if self.selectable_draws else "Raffle complete",
                        "{} winner(s)".format(len(winners)) if self.selectable_draws else
                        "{} winners".format(len(winners)),
                        warning or message,
                        "simple-raffle-result is-winner")
            except Exception as exc:
                if self.config.logger:
                    self.config.logger.exception("Raffle action failed")
                message = str(exc) if isinstance(exc, ValueError) else "Raffle data is unavailable. Try again."
                return ("Draw unavailable", "-", message,
                        "simple-raffle-result is-error")

        @callback(
            Output(id_("results-download"), "data"),
            Input(id_("export-button"), "n_clicks"), prevent_initial_call=True,
        )
        def export_results(clicks):
            if not clicks:
                raise PreventUpdate
            output = io.StringIO(newline="")
            writer = csv.writer(output)
            writer.writerow(["Draw", "OM ID", "Name", "Prize Category", "Prize", "Drawn At"])
            pool = self._pool()
            for r in self.history.read():
                writer.writerow([r["draw_number"], r["uid"], r["name"],
                                 self._prize_category(r.get("prize", ""), pool),
                                 r.get("prize", ""), r["drawn_at"].replace("T", " ")])
            export_date = datetime.now(timezone(timedelta(hours=8))).date().isoformat()
            return {"content": "\ufeff" + output.getvalue(),
                    "filename": f"{self.config.suffix}-results-{export_date}.csv", "type": "text/csv"}
