"""Checked basket submission with one rollback path over existing SQLite files.

Existing tables and public helpers are preserved. ATTACH transactions roll back
application failures together; WAL databases still have SQLite's documented
cross-file host-crash limitation. No claim of distributed/crash atomicity.
"""

from collections import Counter
from datetime import datetime
import hashlib
import json
import re
import sqlite3

from .security import ShoppingValidationError, basket_items, catalogue_digest, unseal, validated_member


def identifier(name):
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name):
        raise ShoppingValidationError("The shopping configuration is unavailable.")
    return '"{}"'.format(name)


def submit_basket(page, om_number, quantities, member_token, review_token):
    if page.config.view_only:
        raise ShoppingValidationError("This page is for browsing rewards only.")
    member = validated_member(page, member_token, om_number)
    review = unseal(page, "review", review_token)
    quantities = basket_items(quantities)
    if review.get("member_nonce") != member["nonce"] or review.get("items") != quantities:
        raise ShoppingValidationError("Your basket changed. Review it again before confirming.")
    uid = member["uid"]
    details = page.lookup_member(uid)
    if details["tag"] != member.get("tag"):
        raise ShoppingValidationError("Your reward entitlement changed. Check your OM Number again.")
    df = page.read_prize_pool(details["tag"])
    if catalogue_digest(df) != member.get("catalogue"):
        raise ShoppingValidationError("The rewards catalogue changed. Check your OM Number and select again.")
    if any(int(item_id) not in df.index for item_id in quantities):
        raise ShoppingValidationError("A selected reward is no longer available. Check your OM Number again.")
    shop = page._shop_transaction()
    inventory = page._inventory(details["tag"])
    order_table = identifier(page.config.orders_table)
    prize_table = identifier(page.config.prize_table)
    receipt = hashlib.sha256(review["nonce"].encode("ascii")).hexdigest()
    conn = sqlite3.connect(shop.path, timeout=10, isolation_level=None)
    try:
        conn.execute("ATTACH DATABASE ? AS stock", (inventory.path,))
        conn.execute("ATTACH DATABASE ? AS audit", (shop.log_path,))
        conn.execute("ATTACH DATABASE ? AS stock_audit", (inventory.log_path,))
        conn.execute("BEGIN IMMEDIATE")
        if conn.execute("SELECT 1 FROM audit.logs WHERE action='REDEEM_REQUEST' AND details=? LIMIT 1", (receipt,)).fetchone():
            raise ShoppingValidationError("This confirmation has already been processed. Refresh to see your updated balance.")
        redeemed = int(conn.execute("SELECT COALESCE(SUM(total_cost),0) FROM {} WHERE uid=?".format(order_table), (uid,)).fetchone()[0])
        unlimited = page.has_unlimited_redemptions(uid)
        available = max(0, int(details["balance"]) - (0 if unlimited else redeemed))
        since, until = page.get_redeemed_window()
        query = "SELECT item,SUM(quantity) FROM {} WHERE uid=?".format(order_table)
        params = [uid]
        if since:
            query += " AND createddate>=?"
            params.append(since)
        if until:
            query += " AND createddate<?"
            params.append(until)
        query += " GROUP BY item"
        name_to_category = {str(row["name"]).strip(): str(row["category"]).strip() for _, row in df.drop_duplicates("name").iterrows()}
        previous = Counter()
        for name, quantity in conn.execute(query, params):
            if str(name).strip() in name_to_category:
                previous[name_to_category[str(name).strip()]] += int(quantity)
        requested = Counter()
        total = 0
        lines = []
        for key, quantity in quantities.items():
            row = df.loc[int(key)]
            record = conn.execute("SELECT name,cost,category,inventory FROM stock.{} WHERE ID=?".format(prize_table), (int(key),)).fetchone()
            if not record or (str(record[0]), int(record[1]), str(record[2]).strip()) != (str(row["name"]), int(row["cost"]), str(row["category"]).strip()):
                raise ShoppingValidationError("A selected reward changed. Check your OM Number and select again.")
            if record[3] < quantity:
                raise ShoppingValidationError("A selected reward has insufficient stock. Reduce its quantity and try again.")
            if int(record[1]) < 0:
                raise ShoppingValidationError("A selected reward is unavailable.")
            requested[str(row["category"]).strip()] += quantity
            line_total = int(row["cost"]) * quantity
            total += line_total
            lines.append((int(key), str(row["name"]), quantity, int(row["cost"]), line_total))
        if total > available:
            raise ShoppingValidationError("Your available TP changed or is insufficient. Check your OM Number again.")
        if not unlimited:
            if not page._within_redemption_limit(previous, sum(quantities.values()), uid):
                raise ShoppingValidationError("The campaign redemption limit has been reached.")
            if any(previous[category] + quantity > page.get_category_limit(uid) for category, quantity in requested.items()):
                raise ShoppingValidationError("The redemption limit for a category has been reached.")
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        for item_id, name, quantity, price, line_total in lines:
            duplicate = conn.execute("SELECT 1 FROM {} WHERE uid=? AND item_id=? AND item=? AND quantity=? AND cost=? AND ABS(strftime('%s',createddate)-strftime('%s',?))<=30 LIMIT 1".format(order_table), (uid, item_id, name, quantity, price, now)).fetchone()
            if duplicate:
                raise ShoppingValidationError("This reward was just redeemed. Refresh to review your updated balance.")
            updated = conn.execute("UPDATE stock.{} SET inventory=inventory-? WHERE ID=? AND inventory>=?".format(prize_table), (quantity, item_id, quantity))
            if updated.rowcount != 1:
                raise ShoppingValidationError("Stock changed while confirming. Review your rewards and try again.")
            conn.execute("INSERT INTO {} (uid,createddate,updateddate,item_id,item,quantity,cost,total_cost,credits_used,cp_used,status) VALUES (?,?,?,?,?,?,?,?,?,?,?)".format(order_table), (uid, now, now, item_id, name, quantity, price, line_total, line_total, 0, "pending"))
            conn.execute("INSERT INTO stock_audit.logs (timestamp,user,action,status,details) VALUES (?,?,?,?,?)", (now, inventory.user, "SUBTRACT_QUANTITY", "SUCCESS", "ID={}, Quantity={}".format(item_id, quantity)))
        # A durable request receipt uses the existing logs schema, contains no
        # member details, and is written in the same rollback boundary.
        conn.execute("INSERT INTO audit.logs (timestamp,user,action,status,details) VALUES (?,?,?,?,?)", (now, shop.user, "REDEEM_REQUEST", "COMMITTED", receipt))
        conn.commit()
        return total
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
