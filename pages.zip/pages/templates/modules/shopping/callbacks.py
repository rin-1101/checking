"""Dash callback registration for shopping pages."""

from datetime import datetime
from functools import wraps
from typing import Dict

import dash
from dash import (
    ALL,
    Input,
    Output,
    State,
    callback,
    clientside_callback,
    ctx,
    html,
)
from dash.exceptions import PreventUpdate

from .rendering import root_class
from .security import ShoppingValidationError, basket_items, catalogue_digest, seal, validated_member
from .redemption import submit_basket


class ShopCallbacksMixin(object):
    def _register_callbacks(self) -> None:
        cfg = self.config
        id_ = self.id
        wid = self.wid

        def guarded_callback(*args, **kwargs):
            register = callback(*args, **kwargs)

            def decorate(function):
                @wraps(function)
                def checked(*values, **options):
                    try:
                        self.assert_access()
                    except ShoppingValidationError:
                        # Dash can initialize callbacks while the login shell is
                        # still resolving. Denial is an expected state, not an
                        # HTTP error; never run the protected callback body.
                        raise PreventUpdate from None
                    return function(*values, **options)
                return register(checked)
            return decorate

        def _resolve_callback_coding_tag(coding_context=None, om_number=None):
            tag = self._normalize_coding_tag(coding_context)
            if not cfg.bdcoding or not om_number:
                return tag

            current_om = self.format_om(om_number)
            stored_om = coding_context.get("om") if isinstance(coding_context, dict) else None
            if stored_om and self.format_om(stored_om) == current_om:
                return tag

            self.logger.info("Refreshing shopping entitlement context")
            with self.loader_session() as loader:
                fresh_tag, _coding_display, _coding_source = self.get_coding_tag(
                    current_om, loader=loader
                )
            return self._normalize_coding_tag(fresh_tag) or tag

        def _build_basket_content(df, quantities):
            rows = []
            total = 0
            for idx_str, raw_qty in (quantities or {}).items():
                try:
                    idx = int(idx_str)
                    qty = int(raw_qty or 0)
                    if qty <= 0 or idx not in df.index:
                        continue
                    name = df.loc[idx, "name"]
                    price = df.loc[idx, "cost"]
                except (TypeError, ValueError, KeyError):
                    continue

                line_total = price * qty
                total += line_total
                rows.append(html.Div(
                    className="shop-basket-row",
                    children=[
                        html.Div(
                            className="shop-basket-item-copy",
                            children=[
                                html.Strong(name),
                                html.Span("{} {} each".format(price, cfg.currency_label)),
                            ],
                        ),
                        html.Div(
                            className="shop-basket-row-actions",
                            children=[
                                html.Button(
                                    "-",
                                    id=wid("basket-decrease", idx),
                                    n_clicks=0,
                                    className="shop-basket-adjust",
                                    **{"aria-label": "Reduce {}".format(name)}
                                ),
                                html.Span(
                                    "Qty {}".format(qty),
                                    className="shop-basket-row-quantity",
                                ),
                                html.Button(
                                    "Remove",
                                    id=wid("basket-remove", idx),
                                    n_clicks=0,
                                    className="shop-basket-remove",
                                ),
                            ],
                        ),
                        html.Strong(
                            "{} {}".format(line_total, cfg.currency_label),
                            className="shop-basket-line-total",
                        ),
                    ],
                ))

            if not rows:
                return html.Div(
                    "No items selected.",
                    className="shop-empty-basket",
                )

            return html.Div(children=[
                html.Div(rows, className="shop-basket-rows"),
                html.Div(
                    className="shop-basket-modal-total",
                    children=[
                        html.Span("TOTAL"),
                        html.Strong("{} {}".format(total, cfg.currency_label)),
                    ],
                ),
            ])

        @guarded_callback(
            Output(id_("main-container"), "className"),
            Input(id_("style-selector"), "value"),
            Input(id_("coding-tag"), "data"),
            Input(id_("url"), "search"),
        )
        def switch_shop_style(selected_style, coding_tag, search):
            return root_class(cfg, selected_style, search)

        # ---- 1. Validate player, hydrate stores, and build item grid ----
        @callback(
            Output(id_("visible-rows"), "data"),
            Output(id_("items-grid"), "children"),
            Output(id_("item-limit-store"), "data"),
            Output(id_("token"), "data"),
            Output(id_("red"), "data"),
            Output(id_("initials-textbox"), "value"),
            Output(id_("tier-textbox"), "value"),
            *([Output(id_("tagging-textbox"), "value")] if cfg.bdcoding else []),
            Output(id_("coding-tag"), "data"),
            Output(id_("items-grid"), "className"),
            Output(id_("Error-text"), "children"),
            Output(id_("credits-section"), "style"),
            Output(id_("main-container-items"), "style"),
            Output(id_("logo-main"), "style"),
            Output(id_("prev-redeemed-by-cat"), "data"),
            Output(id_("df-length"), "data"),
            Output(id_("category-filter"), "options"),
            Output(id_("category-filter"), "value"),
            Output(id_("main-container"), "style"),
            Output(id_("background-artwork"), "children"),
            Output(id_("validated-member"), "data"),
            Output(id_("validated-uid"), "data"),
            *([Output(id_("redeem-footer"), "className"),
               Output(id_("redeem-footer"), "style")] if not cfg.view_only else []),
            Input(id_("export-button"), "n_clicks"),
            Input(id_("uid-textbox"), "n_submit"),
            State(id_("uid-textbox"), "value"),
            running=[
                (Output(id_("export-button"), "disabled"), True, False),
                (Output(id_("uid-textbox"), "disabled"), True, False),
                (Output(id_("lookup-pending"), "children"), "Checking your rewards...", ""),
            ],
            prevent_initial_call=True,
        )
        def validate_player(n_clicks, n_submit, om_number):
            hidden = {"display": "none"}
            extra_hidden = ("shop-redeem-footer is-hidden", hidden) if not cfg.view_only else ()
            extra_shown = ("shop-redeem-footer", {"display": "flex"}) if not cfg.view_only else ()

            def reject(message):
                tagging = ("",) if cfg.bdcoding else ()
                return (([], [], 0, 0, 0, "", "") + tagging +
                        (None, "shop-items-grid is-hidden", message, hidden, {},
                         hidden, {}, 0, [{"label": "ALL", "value": "all"}], "all",
                         self.get_background_style_for_tag(), self.get_background_artwork(), None, None) + extra_hidden)

            try:
                self.assert_access()
                if not om_number or not self.is_valid_om(om_number):
                    return reject("Please enter a valid OM Number.")
                member = self.lookup_member(om_number)
                om, tag = member["uid"], member["tag"]
                df = self.read_prize_pool(tag)
                redeemed, previous = self.get_redemption_summary(om, df)
                available = max(0, member["balance"] - redeemed)
                eligible = df[(df["inventory"] > 0) & (df["cost"] <= available)]
                unavailable = (not self.has_unlimited_redemptions(om) and
                               not self._within_redemption_limit(previous, 1, om))
                cards = [self._build_item_card(i, df.loc[i], tag, unavailable=unavailable)
                         for i in eligible.index]
                options = [{"label": "ALL", "value": "all"}]
                seen = set()
                for raw in eligible["category"]:
                    label = str(raw or "").strip()
                    value = self.category_slug(label)
                    if label and label.casefold() != "nan" and value not in seen:
                        options.append({"label": label.upper(), "value": value})
                        seen.add(value)
                token = seal(self, "member", {"uid": om, "tag": tag,
                                              "catalogue": catalogue_digest(df)})
                tagging = (member["tagging"],) if cfg.bdcoding else ()
                return ((eligible.index.tolist(), cards, available, member["balance"],
                         redeemed, member["initials"], member["tier"]) + tagging +
                        ({"om": om, "tag": tag}, "shop-items-grid", "", {"display": "block"},
                         {}, hidden, previous, len(df), options, "all",
                         self.get_background_style_for_tag(tag), self.get_background_artwork(tag), token, om) + extra_shown)
            except ShoppingValidationError as exc:
                return reject(str(exc))
            except Exception as exc:
                self.logger.error("Shopping lookup failed (%s)", type(exc).__name__)
                return reject("We could not retrieve your rewards. Please try Check again.")

        # ---- 3. TP display boxes ---------------------------------------
        @guarded_callback(
            Output(id_("tp-display"), "value"),
            Output(id_("tp-redeem"), "value"),
            Output(id_("tp-balance"), "value"),
            Input(id_("token"), "data"),
            State(id_("red"), "data"),
        )
        def update_tp_display(token, red):
            try:
                token_val = float(token) if token is not None else 0
                balance = max(token_val - (red or 0), 0)
                return token, red, balance
            except (TypeError, ValueError):
                return 0, 0, 0

        # Refresh is explicit. Confirmation never schedules a timed reload.
        @guarded_callback(
            Output(id_("url"), "href"),
            Input(id_("back-button"), "n_clicks"),
            State(id_("url"), "search"),
            prevent_initial_call=True,
        )
        def page_refresh(clicks, search):
            return cfg.page_path + (search or "") if clicks else dash.no_update

        # ---- 5. Modal open/close ----------------------------------------
        @guarded_callback(
            Output(id_("selected-item-id"), "data"),
            Output(id_("item-description"), "className"),
            Input(wid("card", ALL), "n_clicks"),
            Input(id_("close-button"), "n_clicks"),
            *([Input(id_("item-add"), "n_clicks")] if not cfg.view_only else []),
            prevent_initial_call=True,
        )
        def manage_item_modal(card_clicks, close_clicks, *maybe_add):
            triggered = ctx.triggered_id

            if triggered is None:
                raise PreventUpdate

            if isinstance(triggered, str):
                if triggered == id_("close-button"):
                    return None, "modal"

                if not cfg.view_only and triggered == id_("item-add"):
                    return None, "modal"

                raise PreventUpdate

            if hasattr(triggered, "get"):
                if triggered.get("type") == f"card-{self.suffix}":
                    idx = int(triggered.get("index", -1))

                    # Pattern-match click lists are positional, while idx is the
                    # prize-pool database index and may be non-contiguous.
                    if card_clicks and any(card_clicks):
                        return idx, "modal is-active"

            raise PreventUpdate

        # ---- 6a. Load modal content -------------------------------------
        @guarded_callback(
            Output(id_("item-image"), "src"),
            Output(id_("item-name"), "children"),
            Output(id_("item-cost"), "children"),
            Output(id_("modal-item-index"), "data"),
            Output(id_("qty"), "children"),
            Output(id_("current-quantity"), "data"),
            Output(id_("category-limit-warning"), "children"),
            Input(id_("selected-item-id"), "data"),
            State(id_("quantities-store"), "data") if not cfg.view_only else State(id_("modal-item-index"), "data"),
            State(id_("prev-redeemed-by-cat"), "data"),
            State(id_("coding-tag"), "data"),
            State(id_("uid-textbox"), "value"),
            prevent_initial_call=True,
        )
        def load_modal_content(selected_idx, quantities, prev_cat_counts, coding_tag, om_number):
            if selected_idx is None:
                raise PreventUpdate
            try:
                idx = int(selected_idx)
            except (TypeError, ValueError):
                raise PreventUpdate

            coding_tag = _resolve_callback_coding_tag(coding_tag, om_number)
            df = self.read_prize_pool(coding_tag)
            if idx not in df.index:
                raise PreventUpdate

            quantities = quantities if (not cfg.view_only and quantities) else {}
            prev_cat_counts = prev_cat_counts or {}

            qty = int(quantities.get(str(idx), 0)) if not cfg.view_only else 0
            category = str(df.at[idx, "category"]).strip()
            warning = (
                ""
                if self.has_unlimited_redemptions(om_number)
                else self._redemption_warning(prev_cat_counts, om_number)
                    or self._category_warning(category, prev_cat_counts, om_number)
            )
            assetspath = f"/assets/inventory/{cfg.assets_folder}/{df.loc[idx, 'ID']}.png"
            # assetspath = f"/assets/inventory/{cfg.assets_folder}/{coding_tag}/{df.loc[idx, 'ID']}.png"
            if(coding_tag and coding_tag != "DEFAULT"):
                assetspath = f"/assets/inventory/{cfg.assets_folder}/{coding_tag}/{df.loc[idx, 'ID']}.png"
            # if not self.asset_exists(assetspath):
            #     assetspath = f"/assets/DEFAULT/okada-long.png"
            return (
                assetspath,
                df.loc[idx, "name"],
                f"{df.loc[idx, 'cost']} {cfg.currency_label}",
                idx, qty, qty, warning,
            )

        clientside_callback(
            """
            function(category, searchText, itemIds) {
                var selected = category || "all";
                var needle = String(searchText || "").toLowerCase()
                    .replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
                var count = 0;
                var styles = (itemIds || []).map(function(itemId) {
                    var parts = String((itemId || {}).index || "").split("|");
                    var match = (selected === "all" || parts[0] === selected) &&
                        (!needle || (parts[1] || "").indexOf(needle) !== -1);
                    if (match) { count += 1; }
                    return match ? {} : {display:"none"};
                });
                var empty = (itemIds || []).length ?
                    "No rewards match these filters. Clear filters to browse again." :
                    "No eligible rewards are available for your current TP balance and stock.";
                return [styles, count + (count === 1 ? " reward" : " rewards"),
                    empty, {display:count ? "none" : "block"}, {display:needle || selected !== "all" ? "inline-block" : "none"}];
            }
            """,
            Output(wid("catalog-item", ALL), "style"),
            Output(id_("catalogue-status"), "children"),
            Output(id_("catalogue-empty"), "children"),
            Output(id_("catalogue-empty"), "style"),
            Output(id_("clear-filters"), "style"),
            Input(id_("category-filter"), "value"),
            Input(id_("catalog-search"), "value"),
            Input(wid("catalog-item", ALL), "id"),
        )
        clientside_callback(
            "function(clicks){return ['all',''];}",
            Output(id_("category-filter"), "value", allow_duplicate=True),
            Output(id_("catalog-search"), "value"),
            Input(id_("clear-filters"), "n_clicks"), prevent_initial_call=True,
        )
        clientside_callback(
            """function(value, validated) {
                var digits = String(value || '').replace(/[^0-9]/g,'');
                var om = digits ? 'OM' + '000000000'.slice(digits.length) + digits : '';
                var match = !!validated && om === validated;
                return [match ? 'true' : 'false', validated && !match ?
                    'OM Number changed. Check it again to view your rewards.' : ''];
            }""",
            Output(id_("main-container"), "data-verified"),
            Output(id_("member-change-status"), "children"),
            Input(id_("uid-textbox"), "value"), Input(id_("validated-uid"), "data"),
        )

        if cfg.view_only:
            return  # Everything below is cart/redeem logic ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â view-only stops here.

        clientside_callback(
            "function(token,result,pending,blocked){return !token || !!pending || !!blocked || !!(result && result.success);}",
            Output(id_("confirm-redeem-button"), "disabled"),
            Input(id_("confirmation-token"), "data"), Input(id_("redemption-result"), "data"),
            Input(id_("submission-pending"), "data"), Input(id_("confirmation-blocked"), "data"),
        )

        clientside_callback(
            """function(quantities,value,validated) {
                var digits=String(value||'').replace(/[^0-9]/g,'');
                var om=digits ? 'OM'+'000000000'.slice(digits.length)+digits : '';
                var count=Object.keys(quantities||{}).reduce(function(sum,key){return sum+Number(quantities[key]||0);},0);
                return !validated || om!==validated || count<=0;
            }""",
            Output(id_("redeem-button"), "disabled"),
            Input(id_("quantities-store"), "data"), Input(id_("uid-textbox"), "value"),
            Input(id_("validated-uid"), "data"),
        )

        # ---- 6b. Quantity controls (+/-) --------------------------------
        @guarded_callback(
            Output(id_("qty"), "children", allow_duplicate=True),
            Output(id_("current-quantity"), "data", allow_duplicate=True),
            Output(id_("category-limit-warning"), "children", allow_duplicate=True),
            Input(id_("add-button"), "n_clicks"),
            Input(id_("sub-button"), "n_clicks"),
            State(id_("current-quantity"), "data"),
            State(id_("modal-item-index"), "data"),
            State(id_("quantities-store"), "data"),
            State(id_("item-limit-store"), "data"),
            State(id_("prev-redeemed-by-cat"), "data"),
            State(id_("coding-tag"), "data"),
            State(id_("uid-textbox"), "value"),
            prevent_initial_call=True,
        )
        def update_quantity(add_clicks, sub_clicks, curr_qty, curr_idx, quantities, lim, prev_cat_counts, coding_tag, om_number):
            triggered = ctx.triggered_id
            if triggered not in (id_("add-button"), id_("sub-button")):
                raise PreventUpdate
            if curr_idx is None:
                raise PreventUpdate

            try:
                curr_idx = int(curr_idx)
            except (TypeError, ValueError):
                raise PreventUpdate

            coding_tag = _resolve_callback_coding_tag(coding_tag, om_number)
            df = self.read_prize_pool(coding_tag)
            if curr_idx not in df.index:
                raise PreventUpdate

            df["category"] = df["category"].astype(str).str.strip()
            category = df.at[curr_idx, "category"]
            cost = float(df.at[curr_idx, "cost"])
            inv = int(df.at[curr_idx, "inventory"])
            curr_qty = int(curr_qty or 0)
            quantities = quantities or {}
            prev_cat_counts = prev_cat_counts or {}
            lim = lim or 0

            parsed_q: Dict[int, int] = {}
            for k, v in quantities.items():
                try:
                    parsed_q[int(k)] = int(v or 0)
                except Exception:
                    continue

            total_cost_excl = sum(
                float(df.at[i, "cost"]) * q for i, q in parsed_q.items() if i != curr_idx
            )
            cart_cat_excl = sum(
                q for i, q in parsed_q.items()
                if i != curr_idx and df.at[i, "category"] == category
            )
            cart_qty_excl = sum(
                max(0, q) for i, q in parsed_q.items() if i != curr_idx
            )
            prev_redeemed_cat = int(prev_cat_counts.get(category, 0))
            unlimited_redemptions = self.has_unlimited_redemptions(om_number)
            category_limit = self.get_category_limit(om_number)

            new_qty = curr_qty
            if triggered == id_("add-button"):
                proposed_qty = curr_qty + 1
                total_cat_used = prev_redeemed_cat + cart_cat_excl + proposed_qty
                if (
                    proposed_qty <= inv
                    and (total_cost_excl + proposed_qty * cost) <= lim
                    and (
                        unlimited_redemptions
                        or (
                            self._within_redemption_limit(
                                prev_cat_counts,
                                cart_qty_excl + proposed_qty,
                                om_number,
                            )
                            and total_cat_used <= category_limit
                        )
                    )
                ):
                    new_qty = proposed_qty
            else:
                new_qty = max(0, curr_qty - 1)

            warning = (
                ""
                if unlimited_redemptions
                else self._category_warning(category, prev_cat_counts, om_number)
            )
            if triggered == id_("add-button") and new_qty == curr_qty:
                if curr_qty + 1 > inv:
                    warning = "No more stock is available for this reward."
                elif total_cost_excl + (curr_qty + 1) * cost > lim:
                    warning = "You do not have enough TP for another item."
                elif not self._within_redemption_limit(prev_cat_counts, cart_qty_excl + curr_qty + 1, om_number):
                    warning = "The campaign redemption limit has been reached."
                else:
                    warning = "The limit for this reward category has been reached."
            return new_qty, new_qty, warning

        # ---- 7. Cart store + total value --------------------------------
        @guarded_callback(
            Output(id_("quantities-store"), "data"),
            Output(id_("total-value"), "children"),
            Output(id_("cart-value"), "data"),
            Input(id_("item-add"), "n_clicks"),
            Input(id_("export-button"), "n_clicks"),
            Input(id_("uid-textbox"), "n_submit"),
            State(id_("modal-item-index"), "data"),
            State(id_("current-quantity"), "data"),
            State(id_("quantities-store"), "data"),
            State(id_("coding-tag"), "data"),
            State(id_("uid-textbox"), "value"),
            prevent_initial_call=True,
        )
        def update_cart(add_click, exp, submitted, curr_idx, curr_qty, quantities, coding_tag, om_number):
            triggered = ctx.triggered_id
            if triggered in (id_("export-button"), id_("uid-textbox")):
                return {}, 0, 0
            if not triggered or curr_idx is None:
                raise PreventUpdate

            coding_tag = _resolve_callback_coding_tag(coding_tag, om_number)
            df = self.read_prize_pool(coding_tag)
            quantities = quantities or {}
            key = str(curr_idx)

            if curr_qty == 0:
                quantities.pop(key, None)
            else:
                quantities[key] = curr_qty

            total = self.calculate_total_value(quantities, df)
            return quantities, total, total

        # ---- 7b. Quick add from catalogue cards -------------------------
        if cfg.quick_add:
            @guarded_callback(
                Output(id_("quantities-store"), "data", allow_duplicate=True),
                Output(id_("total-value"), "children", allow_duplicate=True),
                Output(id_("cart-value"), "data", allow_duplicate=True),
                Input(wid("quick-add", ALL), "n_clicks"),
                State(id_("quantities-store"), "data"),
                State(id_("item-limit-store"), "data"),
                State(id_("prev-redeemed-by-cat"), "data"),
                State(id_("coding-tag"), "data"),
                State(id_("uid-textbox"), "value"),
                prevent_initial_call=True,
            )
            def quick_add_to_cart(clicks, quantities, limit, prev_cat_counts,
                                  coding_tag, om_number):
                triggered = ctx.triggered_id
                if (
                    not isinstance(triggered, dict)
                    or triggered.get("type") != "quick-add-{}".format(self.suffix)
                    or not any(clicks or [])
                ):
                    raise PreventUpdate

                try:
                    idx = int(triggered.get("index"))
                except (TypeError, ValueError):
                    raise PreventUpdate

                coding_tag = _resolve_callback_coding_tag(coding_tag, om_number)
                df = self.read_prize_pool(coding_tag)
                if idx not in df.index:
                    raise PreventUpdate

                df["category"] = df["category"].astype(str).str.strip()
                updated = dict(quantities or {})
                prev_cat_counts = prev_cat_counts or {}
                category = df.at[idx, "category"]
                current_qty = int(updated.get(str(idx), 0) or 0)
                inventory = int(df.at[idx, "inventory"])
                cost = float(df.at[idx, "cost"])
                current_total = self.calculate_total_value(updated, df)
                basket_quantity = sum(
                    max(0, int(raw_qty or 0))
                    for raw_qty in updated.values()
                )
                cart_category_qty = sum(
                    int(raw_qty or 0)
                    for raw_idx, raw_qty in updated.items()
                    if int(raw_idx) in df.index
                    and df.at[int(raw_idx), "category"] == category
                )
                previously_redeemed = int(prev_cat_counts.get(category, 0))
                unlimited_redemptions = self.has_unlimited_redemptions(om_number)
                category_limit = self.get_category_limit(om_number)

                if (
                    current_qty + 1 > inventory
                    or current_total + cost > (limit or 0)
                    or (
                        not unlimited_redemptions
                        and (
                            not self._within_redemption_limit(
                                prev_cat_counts, basket_quantity + 1, om_number
                            )
                            or previously_redeemed + cart_category_qty + 1
                                > category_limit
                        )
                    )
                ):
                    raise PreventUpdate

                updated[str(idx)] = current_qty + 1
                total = self.calculate_total_value(updated, df)
                return updated, total, total

            @guarded_callback(
                Output(wid("card", ALL), "className"),
                Output(wid("quick-add", ALL), "disabled"),
                Input(id_("quantities-store"), "data"),
                Input(id_("item-limit-store"), "data"),
                Input(id_("prev-redeemed-by-cat"), "data"),
                Input(id_("visible-rows"), "data"),
                State(id_("coding-tag"), "data"),
                State(id_("uid-textbox"), "value"),
            )
            def update_card_availability(quantities, limit, prev_cat_counts,
                                         visible_indices, coding_tag, om_number):
                visible_indices = visible_indices or []
                if not visible_indices:
                    return [], []

                coding_tag = _resolve_callback_coding_tag(coding_tag, om_number)
                df = self.read_prize_pool(coding_tag)
                df["category"] = df["category"].astype(str).str.strip()
                prev_cat_counts = prev_cat_counts or {}
                unlimited_redemptions = self.has_unlimited_redemptions(om_number)
                category_limit = self.get_category_limit(om_number)

                parsed_quantities = {}
                for raw_idx, raw_qty in (quantities or {}).items():
                    try:
                        parsed_quantities[int(raw_idx)] = int(raw_qty or 0)
                    except (TypeError, ValueError):
                        continue

                current_total = self.calculate_total_value(
                    {str(idx): qty for idx, qty in parsed_quantities.items()},
                    df,
                )
                basket_by_category = {}
                for idx, qty in parsed_quantities.items():
                    if idx not in df.index or qty <= 0:
                        continue
                    category = df.at[idx, "category"]
                    basket_by_category[category] = (
                        basket_by_category.get(category, 0) + qty
                    )

                basket_quantity = sum(
                    max(0, qty) for qty in parsed_quantities.values()
                )
                card_classes = []
                quick_add_disabled = []
                for raw_idx in visible_indices:
                    try:
                        idx = int(raw_idx)
                    except (TypeError, ValueError):
                        card_classes.append("shop-product-card is-unavailable")
                        quick_add_disabled.append(True)
                        continue

                    if idx not in df.index:
                        card_classes.append("shop-product-card is-unavailable")
                        quick_add_disabled.append(True)
                        continue

                    category = df.at[idx, "category"]
                    selected_qty = parsed_quantities.get(idx, 0)
                    inventory = int(df.at[idx, "inventory"])
                    cost = float(df.at[idx, "cost"])
                    category_used = (
                        int(prev_cat_counts.get(category, 0))
                        + basket_by_category.get(category, 0)
                    )
                    can_add = (
                        selected_qty + 1 <= inventory
                        and current_total + cost <= (limit or 0)
                        and (
                            unlimited_redemptions
                            or (
                                self._within_redemption_limit(
                                    prev_cat_counts,
                                    basket_quantity + 1,
                                    om_number,
                                )
                                and category_used + 1 <= category_limit
                            )
                        )
                    )

                    # Keep selected cards visually active even when another
                    # unit cannot be added; only unselected unavailable cards
                    # are grayed out.
                    card_classes.append(
                        "shop-product-card"
                        if can_add or selected_qty > 0
                        else "shop-product-card is-unavailable"
                    )
                    quick_add_disabled.append(not can_add)

                return card_classes, quick_add_disabled

        # ---- 8. Basket quantity adjustment ------------------------------
        @guarded_callback(
            Output(id_("quantities-store"), "data", allow_duplicate=True),
            Output(id_("total-value"), "children", allow_duplicate=True),
            Output(id_("cart-value"), "data", allow_duplicate=True),
            Output(id_("modal-basket-content"), "children", allow_duplicate=True),
            Output(id_("confirmation-token"), "data", allow_duplicate=True),
            Output(id_("basket-remaining"), "children", allow_duplicate=True),
            Output(id_("basket-feedback"), "children", allow_duplicate=True),
            Input(wid("basket-decrease", ALL), "n_clicks"),
            Input(wid("basket-remove", ALL), "n_clicks"),
            State(id_("quantities-store"), "data"),
            State(id_("coding-tag"), "data"),
            State(id_("uid-textbox"), "value"),
            State(id_("validated-member"), "data"),
            State(id_("item-limit-store"), "data"),
            prevent_initial_call=True,
        )
        def adjust_basket(decrease_clicks, remove_clicks, quantities, coding_tag, om_number, member_token, limit):
            triggered = ctx.triggered_id
            if not isinstance(triggered, dict):
                raise PreventUpdate

            component_type = triggered.get("type")
            if component_type not in (
                "basket-decrease-{}".format(self.suffix),
                "basket-remove-{}".format(self.suffix),
            ):
                raise PreventUpdate

            # Rendering the basket dynamically inserts these pattern-matched
            # buttons with n_clicks=0. Treat only an actual click as a basket
            # mutation; otherwise rebuilding the modal can decrement it again.
            triggered_clicks = (
                decrease_clicks
                if component_type == "basket-decrease-{}".format(self.suffix)
                else remove_clicks
            )
            if not any(triggered_clicks or []):
                raise PreventUpdate

            key = str(triggered.get("index"))
            updated = dict(quantities or {})
            current = int(updated.get(key, 0) or 0)
            if component_type == "basket-remove-{}".format(self.suffix):
                updated.pop(key, None)
            elif current <= 1:
                updated.pop(key, None)
            else:
                updated[key] = current - 1

            coding_tag = _resolve_callback_coding_tag(coding_tag, om_number)
            df = self.read_prize_pool(coding_tag)
            total = self.calculate_total_value(updated, df)
            try:
                member = validated_member(self, member_token, om_number)
                review = seal(self, "review", {"member_nonce": member["nonce"], "items": basket_items(updated)}) if updated else None
            except ShoppingValidationError:
                raise PreventUpdate
            return (updated, total, total, _build_basket_content(df, updated), review,
                    "TP remaining after this basket: {} {}".format((limit or 0) - total, cfg.currency_label), "")

        # ---- 9. Quantity badges on grid cards (clientside) --------------
        clientside_callback(
            """
            function(quantities, visible_indices) {
                return (visible_indices || []).map(function(i) {
                    var idx = String(i);
                    var quantity = (quantities && quantities.hasOwnProperty(idx)) ? quantities[idx] : 0;
                    return Number(quantity) > 0 ? quantity : "";
                });
            }
            """,
            Output(wid("item-qty", ALL), "children"),
            Input(id_("quantities-store"), "data"),
            Input(id_("visible-rows"), "data"),
        )

        # ---- 9. Basket item count (clientside) --------------------------
        clientside_callback(
            """
            function(quantities) {
                var total = Object.keys(quantities || {}).reduce(function(sum, key) {
                    return sum + (Number(quantities[key]) || 0);
                }, 0);
                return total + (total === 1 ? " ITEM" : " ITEMS");
            }
            """,
            Output(id_("cart-item-count"), "children"),
            Input(id_("quantities-store"), "data"),
        )

        # ---- 10. Redeem modal + confirmation flow -----------------------
        @callback(
            Output(id_("redeem-modal"), "style"),
            Output(id_("modal-basket-content"), "children"),
            Output(id_("redeem-status"), "children"),
            Output(id_("uid-textbox"), "value"),
            Output(id_("interval-refresh"), "disabled"),
            Output(id_("confirmation-blocked"), "data"),
            Output(id_("last-confirm-ts"), "data"),
            Output(id_("confirmation-token"), "data"),
            Output(id_("redemption-result"), "data"),
            Output(id_("basket-feedback"), "children"),
            Output(id_("basket-remaining"), "children"),
            Input(id_("redeem-button"), "n_clicks"),
            Input(id_("cancel-redeem-button"), "n_clicks"),
            Input(id_("cancel-redeem-button2"), "n_clicks"),
            Input(id_("confirm-redeem-button"), "n_clicks"),
            State(id_("token"), "data"),
            State(id_("quantities-store"), "data"),
            State(id_("uid-textbox"), "value"),
            State(id_("last-confirm-ts"), "data"),
            State(id_("coding-tag"), "data"),
            State(id_("validated-member"), "data"),
            State(id_("confirmation-token"), "data"),
            running=[(Output(id_("submission-pending"), "data"), True, False)],
            prevent_initial_call=True,
        )
        def handle_redeem_modal(redeem_click, cancel_click, cancel_click2, confirm_click,
                                credits_balance, quantities, om_number, last_ts, coding_tag,
                                member_token, review_token):
            trigger = ctx.triggered_id
            now_ms = int(datetime.now().timestamp() * 1000)
            no = dash.no_update
            shown = {"display": "flex"}
            hidden = {"display": "none"}
            if trigger in (id_("cancel-redeem-button"), id_("cancel-redeem-button2")):
                return hidden, no, no, no, True, False, no, None, no, "", ""
            try:
                self.assert_access()
                member = validated_member(self, member_token, om_number)
                items = basket_items(quantities)
                if trigger == id_("redeem-button"):
                    df = self.read_prize_pool(member["tag"])
                    if catalogue_digest(df) != member["catalogue"]:
                        raise ShoppingValidationError("The catalogue changed. Check your OM Number again.")
                    if any(int(key) not in df.index for key in items):
                        raise ShoppingValidationError("A selected reward changed. Check your OM Number again.")
                    total = self.calculate_total_value(items, df)
                    earned = self.get_balance(member["uid"])
                    redeemed = self.get_redeemed(member["uid"]) if not self.has_unlimited_redemptions(member["uid"]) else 0
                    remaining = max(0, earned - redeemed) - total
                    review = seal(self, "review", {"member_nonce": member["nonce"], "items": items})
                    return (shown, _build_basket_content(df, items), no, no, True,
                            remaining < 0, no, review, None, "",
                            "TP remaining after this basket: {} {}".format(remaining, cfg.currency_label))
                if trigger == id_("confirm-redeem-button"):
                    total = submit_basket(self, om_number, items, member_token, review_token)
                    message = "Your rewards have been confirmed. {} {} redeemed.".format(total, cfg.currency_label)
                    return (shown, no, message, "", True, True, now_ms, None,
                            {"success": True, "at": now_ms}, message, "Check your OM Number again to view the updated balance.")
            except ShoppingValidationError as exc:
                return shown, no, no, no, True, False, now_ms, no, None, str(exc), no
            except Exception as exc:
                self.logger.error("Shopping confirmation failed (%s)", type(exc).__name__)
                return (shown, no, no, no, True, False, now_ms, no, None,
                        "We could not confirm your rewards. Your basket is still here. Please try again or ask for assistance.", no)
            return (no,) * 11
