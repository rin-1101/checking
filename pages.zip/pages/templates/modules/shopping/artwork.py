"""Progressive artwork formats with untouched PNG fallback."""

from functools import lru_cache
import json
from pathlib import Path

from dash import html


@lru_cache(maxsize=1)
def manifest():
    try:
        path = Path(__file__).resolve().parents[4] / "assets" / "shop" / "artwork-manifest.json"
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def picture(folder, filename, class_name, alt="", eager=False):
    source = "{}/{}".format(folder, filename)
    asset = manifest().get(source, {})
    image = html.Img(src="/assets/" + asset.get("fallback", source), className=class_name, alt=alt,
                     **({"width": asset["width"], "height": asset["height"]} if asset else {}))
    if not asset:
        return image
    return html.Picture(children=[html.Source(srcSet="/assets/" + asset["webp"], type="image/webp"), image])
