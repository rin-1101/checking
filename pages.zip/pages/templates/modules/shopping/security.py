"""Signed, short-lived shopping context; no member data in URLs or logs."""

import hashlib
import json
import secrets

from flask import current_app, session
from itsdangerous import BadData, URLSafeTimedSerializer


class ShoppingValidationError(ValueError):
    """A safe message that can be shown to the customer."""


def catalogue_digest(df):
    records = [
        [int(row["ID"]), str(row["name"]), int(row["cost"]), str(row["category"]).strip()]
        for _, row in df.sort_index().iterrows()
    ]
    return hashlib.sha256(json.dumps(records, separators=(",", ":")).encode("utf-8")).hexdigest()


def basket_items(quantities):
    result = {}
    if not isinstance(quantities, dict):
        raise ShoppingValidationError("Select your rewards again.")
    for raw_id, raw_qty in quantities.items():
        # Do not silently truncate fractions, accept booleans or merge alias IDs.
        try:
            item_id, quantity = int(raw_id), int(raw_qty)
        except (ValueError, TypeError, OverflowError):
            raise ShoppingValidationError("Please check the selected quantities.") from None
        if isinstance(raw_qty, bool) or str(raw_qty) != str(quantity):
            raise ShoppingValidationError("Please check the selected quantities.")
        if item_id <= 0 or quantity < 0 or str(item_id) in result:
            raise ShoppingValidationError("Please check the selected quantities.")
        if quantity:
            result[str(item_id)] = quantity
    if not result:
        raise ShoppingValidationError("Your basket is empty. Choose a reward first.")
    return dict(sorted(result.items(), key=lambda pair: int(pair[0])))


def _signer(page, purpose):
    page.assert_access()
    if not current_app.secret_key:
        raise ShoppingValidationError("The shopping session is unavailable. Please sign in again.")
    return URLSafeTimedSerializer(current_app.secret_key, salt="shopping:{}:{}".format(page.suffix, purpose))


def seal(page, purpose, payload):
    browser = session.get("shopping_browser")
    if not browser:
        browser = secrets.token_urlsafe(18)
        session["shopping_browser"] = browser
    data = dict(payload, browser=browser, staff=session.get("_user_id", ""), nonce=secrets.token_urlsafe(18))
    return _signer(page, purpose).dumps(data)


def unseal(page, purpose, token):
    try:
        data = _signer(page, purpose).loads(token or "", max_age=900)
        if data.get("browser") != session.get("shopping_browser") or data.get("staff") != session.get("_user_id", ""):
            raise BadData("Session changed")
        return data
    except (BadData, TypeError, AttributeError):
        raise ShoppingValidationError("Your rewards session has changed or expired. Check your OM Number again.") from None


def validated_member(page, token, om):
    data = unseal(page, "member", token)
    if data.get("uid") != page.format_om(om):
        raise ShoppingValidationError("The OM Number has changed. Check it again before using the basket.")
    return data
