"""Public layout adapter; active markup lives in tablet_layout."""

from .tablet_layout import build_item_card, build_tablet_layout


class ShopLayoutMixin(object):
    def _build_item_card(self, i, row, coding_tag=None, unavailable=False):
        return build_item_card(self, i, row, coding_tag, unavailable)

    def _layout(self):
        return build_tablet_layout(self)

    @property
    def layout(self):
        from dash import html

        def make():
            return html.Div(id=self.id("main-cont"), children=self._layout())
        return make
