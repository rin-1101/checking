"""Explicit, per-page display preferences; no user-agent/global state."""

from urllib.parse import parse_qs


def low_power(config, search=""):
    value = parse_qs((search or "").lstrip("?")).get("performance", [""])[0].lower()
    if value in ("lite", "normal"):
        return value == "lite"
    return config.low_power_mode


def root_class(config, selected_style=None, search=""):
    allowed = {option["value"] for option in config.style_options}
    style = selected_style if selected_style in allowed else config.default_style
    result = "shop-main-container shop-tablet-commerce shop-legacy shop-theme-{}".format(style)
    return result + (" shop-low-power" if low_power(config, search) else "")
