"""Reusable Dash layouts and callbacks for Lotto entry and result pages."""

import base64
import uuid
from datetime import datetime

import dash
from dash import ALL, Input, Output, State, callback, clientside_callback, dcc, html
from dash.exceptions import PreventUpdate

from utils.lotto import (
    LOTTO_TIMEZONE,
    LOTTO_MAX_NUMBER,
    LottoStore,
    LottoPrintStore,
    build_results_workbook,
    count_player_entries,
    match_entries,
    normalize_numbers,
    normalize_om_number,
)
from utils.lotto_earnings import LottoEarnings


def _number_button_class(number, selected):
    class_name = "lotto-number-button"
    if number in selected:
        class_name += " is-selected"
    return class_name


def _number_grid(type_name):
    return html.Div(
        [
            html.Button(
                str(number),
                id={"type": type_name, "index": number},
                n_clicks=0,
                className="lotto-number-button",
            )
            for number in range(1, LOTTO_MAX_NUMBER + 1)
        ],
        className="lotto-number-grid",
    )


class LottoEntryPage(object):
    def __init__(self, suffix="lotto", store=None, earnings=None):
        self.suffix = suffix
        self.store = store or LottoStore()
        self.earnings = earnings or LottoEarnings()
        self.number_type = "lotto-number-{}".format(suffix)

    def id(self, name):
        return "{}-{}".format(name, self.suffix)

    def layout(self):
        def field(label, name, value="--", class_name="lotto-identity-field"):
            return html.Div(
                [html.Span(label), html.Strong(value, id=self.id(name))],
                className=class_name,
            )

        return html.Div(
            [
                html.Link(rel="stylesheet", href="/assets/lotto/style.css"),
                dcc.Store(id=self.id("selected"), data=[]),
                dcc.Store(id=self.id("submission-id"), data=str(uuid.uuid4())),
                dcc.Store(id=self.id("checked-player")),
                html.Main(
                    [
                        html.Div(
                            html.Img(src="/assets/lotto/logo.png", alt="Lotto", className="lotto-campaign-logo"),
                            className="lotto-logo-wrap",
                        ),
                        html.Section(
                            [
                                html.P("MEMBER", className="lotto-member-kicker"),
                                html.Label("OM Number", htmlFor=self.id("player-number"), className="lotto-sr-only"),
                                html.Div(
                                    [
                                        dcc.Input(
                                            id=self.id("player-number"), type="text",
                                            placeholder="Enter OM Number", maxLength=50,
                                            autoComplete="off", inputMode="numeric",
                                            className="lotto-player-input",
                                        ),
                                        html.Button(
                                            "Check", id=self.id("check"), n_clicks=0,
                                            className="lotto-primary-button lotto-check-button",
                                        ),
                                    ],
                                    className="lotto-member-search-row",
                                ),
                                html.Div(
                                    [field("INITIALS", "initials"), field("TIER", "tier")],
                                    className="lotto-identity-row",
                                ),
                                html.Div(
                                    id=self.id("lookup-message"), className="lotto-lookup-message",
                                    role="status", **{"aria-live": "polite"},
                                ),
                            ],
                            className="lotto-lookup-panel",
                        ),
                        html.Section(
                            [
                                html.Section(
                                    [
                                        html.Div(
                                            [
                                                field("TP Earned", "tp-earned", "0", "lotto-metric lotto-compact-tp"),
                                                html.Header(
                                                    [
                                                        html.P(id=self.id("gaming-date"), className="lotto-gaming-date"),
                                                        html.H1("Choose Your Numbers", className="lotto-title"),
                                                        html.P(
                                                            "Select exactly 6 numbers from 1 to {}.".format(LOTTO_MAX_NUMBER),
                                                            className="lotto-subtitle",
                                                        ),
                                                        html.P(
                                                            "Earn 200 TP to receive 3 entries, capped at 3 per gaming day. Each ticket uses 1 entry.",
                                                            className="lotto-subtitle lotto-earning-rule",
                                                        ),
                                                    ],
                                                    className="lotto-heading-summary",
                                                ),
                                                html.Div(
                                                    [
                                                        field("Entries Left", "entry-count", "0", "lotto-metric is-balance"),
                                                        field("Entries Used", "entries-used", "0", "lotto-metric"),
                                                    ],
                                                    className="lotto-entry-balances",
                                                ),
                                            ],
                                            className="lotto-compact-summary", **{"aria-live": "polite"},
                                        ),
                                        _number_grid(self.number_type),
                                        html.Div(
                                            [
                                                html.P("0 of 6 selected", id=self.id("selection-status"), className="lotto-selection-status"),
                                                html.Button(
                                                    "Submit Lotto Entry", id=self.id("submit"), n_clicks=0,
                                                    className="lotto-primary-button", disabled=True,
                                                ),
                                            ],
                                            className="lotto-entry-actions",
                                        ),
                                        html.Div(
                                            id=self.id("submit-message"), className="lotto-message",
                                            **{"aria-live": "polite"},
                                        ),
                                    ],
                                    className="lotto-number-panel",
                                ),
                            ],
                            id=self.id("member-details"), className="lotto-member-details",
                            style={"display": "none"},
                        ),
                    ],
                    className="lotto-start-content",
                ),
            ],
            className="lotto-page lotto-entry-page",
        )

    def register_callbacks(self):
        id_ = self.id
        number_type = self.number_type

        @callback(
            Output({"type": number_type, "index": ALL}, "className"),
            Output(id_("selected"), "data"),
            Output(id_("selection-status"), "children"),
            Output(id_("submit-message"), "children"),
            Output(id_("submit-message"), "className"),
            Output(id_("submission-id"), "data"),
            Output(id_("checked-player"), "data"),
            Output(id_("entry-count"), "children"),
            Output(id_("lookup-message"), "children"),
            Output(id_("member-details"), "style"),
            Output(id_("submit"), "disabled"),
            Output(id_("initials"), "children"),
            Output(id_("tier"), "children"),
            Output(id_("tp-earned"), "children"),
            Output(id_("entries-used"), "children"),
            Output(id_("gaming-date"), "children"),
            Input({"type": number_type, "index": ALL}, "n_clicks"),
            Input(id_("submit"), "n_clicks"),
            Input(id_("check"), "n_clicks"),
            Input(id_("player-number"), "n_submit"),
            Input(id_("player-number"), "value"),
            State(id_("selected"), "data"),
            State(id_("submission-id"), "data"),
            State(id_("checked-player"), "data"),
            State(id_("entry-count"), "children"),
            prevent_initial_call=True,
        )
        def handle_entry(
            number_clicks, submit_clicks, check_clicks, enter_presses,
            player_number, selected_numbers, submission_id, checked_player, entry_count,
        ):
            selected = sorted({int(number) for number in (selected_numbers or [])})
            triggered = dash.ctx.triggered_id

            def response(
                numbers, message="", message_class="lotto-message",
                next_submission=dash.no_update, member=dash.no_update,
                count=dash.no_update, lookup_message=dash.no_update,
                details_style=dash.no_update, initials=dash.no_update,
                tier=dash.no_update, tp=dash.no_update, used=dash.no_update,
                gaming_date=dash.no_update,
            ):
                available = entry_count if count is dash.no_update else count
                member_checked = checked_player if member is dash.no_update else member
                can_submit = bool(member_checked) and int(available or 0) > 0 and len(numbers) == 6
                return (
                    [_number_button_class(number, numbers) for number in range(1, LOTTO_MAX_NUMBER + 1)],
                    numbers, "{} of 6 selected".format(len(numbers)),
                    message, message_class, next_submission, member, count,
                    lookup_message, details_style, not can_submit,
                    initials, tier, tp, used, gaming_date,
                )

            def clear(lookup_message=""):
                return response(
                    [], member=None, count="0", lookup_message=lookup_message,
                    details_style={"display": "none"}, initials="--", tier="--",
                    tp="0", used="0", gaming_date="",
                )

            def current_usage(player, allowance):
                used = count_player_entries(
                    self.store.read(), player, allowance["start"], allowance["end"],
                )
                return used, max(allowance["earned"] - used, 0)

            def metrics(allowance, used, available):
                points = format(int(allowance["tp"]), ",d")
                return dict(
                    count=str(available), used=str(used), tp=points,
                    initials=allowance["initials"], tier=allowance["tier"],
                    gaming_date="Gaming Date: {} | 6 AM to 6 AM (Manila)".format(
                        allowance["start"].strftime("%b %d, %Y"),
                    ),
                )

            if id_("player-number") + ".value" in dash.ctx.triggered_prop_ids:
                return clear()

            if triggered in (id_("check"), id_("player-number")):
                try:
                    player = normalize_om_number(player_number)
                    allowance = self.earnings.lookup(player)
                    used, available = current_usage(player, allowance)
                except Exception as exc:
                    return clear(str(exc))
                return response(
                    [], member={"player": player, "day": allowance["start"].isoformat()},
                    lookup_message="", details_style={}, **metrics(allowance, used, available),
                )

            try:
                if (not isinstance(checked_player, dict)
                        or normalize_om_number(player_number) != checked_player.get("player")):
                    raise ValueError("Check your OM Number first.")
            except ValueError as exc:
                return clear(str(exc))

            if triggered == id_("submit"):
                summary = {}
                try:
                    player = checked_player["player"]
                    allowance = self.earnings.lookup(player)
                    if allowance["start"].isoformat() != checked_player["day"]:
                        return clear("The gaming day has changed. Check your OM Number again.")
                    used, available = current_usage(player, allowance)
                    summary = metrics(allowance, used, available)
                    record, created = self.store.submit(
                        submission_id, player, selected, entry_limit=allowance["earned"],
                        window_start=allowance["start"], window_end=allowance["end"],
                    )
                except Exception as exc:
                    return response(selected, str(exc), "lotto-message is-error", **summary)

                message = "Entry Saved"
                return response(
                    [], message, "lotto-message is-success", next_submission=str(uuid.uuid4()),
                    **metrics(allowance, used + int(created), max(available - int(created), 0)),
                )

            if isinstance(triggered, dict) and triggered.get("type") == number_type:
                number = int(triggered["index"])
                if number in selected:
                    selected.remove(number)
                elif len(selected) >= 6:
                    return response(selected, "A maximum of 6 numbers can be selected.", "lotto-message is-error")
                else:
                    selected.append(number)
                    selected.sort()
                return response(selected)

            return (dash.no_update,) * 16


class LottoResultsPage(object):
    def __init__(self, suffix="lotto-results", store=None):
        self.suffix = suffix
        self.store = store or LottoStore()
        self.number_type = "lotto-winning-number-{}".format(suffix)

    def id(self, name):
        return "{}-{}".format(name, self.suffix)

    def layout(self):
        return html.Div(
            [
                html.Link(rel="stylesheet", href="/assets/lotto/style.css"),
                dcc.Store(id=self.id("winning-numbers"), data=[]),
                dcc.Store(id=self.id("results"), data=[]),
                dcc.Download(id=self.id("download")),
                html.Main(
                    [
                        html.Header(
                            [
                                html.P("LOTTO", className="lotto-kicker"),
                                html.H1("Winning Numbers", className="lotto-title"),
                                html.P(
                                    "Select the 6 official winning numbers.",
                                    className="lotto-subtitle",
                                ),
                            ],
                            className="lotto-header",
                        ),
                        _number_grid(self.number_type),
                        html.P(
                            "0 of 6 selected",
                            id=self.id("selection-status"),
                            className="lotto-selection-status",
                        ),
                        html.Div(
                            [
                                html.Button(
                                    "Check Results",
                                    id=self.id("check"),
                                    n_clicks=0,
                                    className="lotto-primary-button",
                                ),
                                html.Button(
                                    "Export Excel",
                                    id=self.id("export"),
                                    n_clicks=0,
                                    className="lotto-secondary-button",
                                ),
                            ],
                            className="lotto-result-actions",
                        ),
                        html.Div(
                            id=self.id("message"),
                            className="lotto-message",
                            **{"aria-live": "polite"},
                        ),
                        html.Div(id=self.id("groups"), className="lotto-result-groups"),
                    ],
                    className="lotto-card lotto-results-card",
                ),
            ],
            className="lotto-page",
        )

    def _result_groups(self, results):
        groups = []
        for match_count in range(1, 7):
            matched = [
                result for result in results if int(result["matches"]) == match_count
            ]
            rows = [
                html.Tr(
                    [
                        html.Td(result["player_number"]),
                        html.Td(result["selected_numbers"]),
                        html.Td(str(result["submitted_at"]).replace("T", " ")),
                    ]
                )
                for result in matched
            ]
            if not rows:
                rows = [
                    html.Tr(
                        html.Td(
                            "No winners",
                            colSpan=3,
                            className="lotto-empty-result",
                        )
                    )
                ]
            groups.append(
                html.Section(
                    [
                        html.H2(
                            "{} Match{} ({})".format(
                                match_count,
                                "" if match_count == 1 else "es",
                                len(matched),
                            ),
                            className="lotto-group-title",
                        ),
                        html.Div(
                            html.Table(
                                [
                                    html.Thead(
                                        html.Tr(
                                            [
                                                html.Th("Player Number"),
                                                html.Th("Selected Numbers"),
                                                html.Th("Submitted At"),
                                            ]
                                        )
                                    ),
                                    html.Tbody(rows),
                                ],
                                className="lotto-results-table",
                            ),
                            className="lotto-table-wrap",
                        ),
                    ],
                    className="lotto-result-group",
                )
            )
        return groups

    def register_callbacks(self):
        id_ = self.id
        number_type = self.number_type

        @callback(
            Output({"type": number_type, "index": ALL}, "className"),
            Output(id_("winning-numbers"), "data"),
            Output(id_("selection-status"), "children"),
            Input({"type": number_type, "index": ALL}, "n_clicks"),
            State(id_("winning-numbers"), "data"),
            prevent_initial_call=True,
        )
        def toggle_winning_number(number_clicks, winning_numbers):
            selected = sorted({int(number) for number in (winning_numbers or [])})
            triggered = dash.ctx.triggered_id
            if not isinstance(triggered, dict) or triggered.get("type") != number_type:
                return (dash.no_update,) * 3

            number = int(triggered["index"])
            if number in selected:
                selected.remove(number)
            elif len(selected) < 6:
                selected.append(number)
                selected.sort()

            return (
                [_number_button_class(value, selected) for value in range(1, LOTTO_MAX_NUMBER + 1)],
                selected,
                "{} of 6 selected".format(len(selected)),
            )

        @callback(
            Output(id_("groups"), "children"),
            Output(id_("results"), "data"),
            Output(id_("message"), "children"),
            Output(id_("message"), "className"),
            Input(id_("check"), "n_clicks"),
            State(id_("winning-numbers"), "data"),
            prevent_initial_call=True,
        )
        def check_results(check_clicks, winning_numbers):
            if not check_clicks:
                raise PreventUpdate
            try:
                winning = normalize_numbers(winning_numbers)
                results = match_entries(self.store.read(), winning)
            except Exception as exc:
                return [], [], str(exc), "lotto-message is-error"

            matched_count = sum(1 for result in results if result["matches"] > 0)
            return (
                self._result_groups(results),
                results,
                "Checked {:,} entries; {:,} have at least one match.".format(
                    len(results),
                    matched_count,
                ),
                "lotto-message is-success",
            )

        @callback(
            Output(id_("download"), "data"),
            Input(id_("export"), "n_clicks"),
            State(id_("results"), "data"),
            State(id_("winning-numbers"), "data"),
            prevent_initial_call=True,
        )
        def export_results(export_clicks, results, winning_numbers):
            if not export_clicks or not results:
                raise PreventUpdate
            workbook = build_results_workbook(results, winning_numbers)
            filename = "Lotto_Results_{}.xlsx".format(
                datetime.now(LOTTO_TIMEZONE).strftime("%Y%m%d_%H%M%S")
            )
            return {
                "content": base64.b64encode(workbook).decode("ascii"),
                "filename": filename,
                "type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "base64": True,
            }


class LottoTicketsPage(object):
    def __init__(self, suffix="lotto-tickets", store=None, print_store=None):
        self.suffix = suffix
        self.store = store or LottoStore()
        self.print_store = print_store or LottoPrintStore()
        self.print_button_type = "lotto-ticket-print-{}".format(suffix)

    def id(self, name):
        return "{}-{}".format(name, self.suffix)

    @staticmethod
    def _record_numbers(record):
        return [str(record.get("number_{}".format(index), "")) for index in range(1, 7)]

    def _ticket(self, record, printable=False, print_summary=None):
        numbers = self._record_numbers(record)
        children = [
            html.P("LOTTO ENTRY", className="lotto-ticket-kicker"),
            html.H2(record.get("player_number", ""), className="lotto-ticket-player"),
            html.P(
                str(record.get("submitted_at", "")).replace("T", " "),
                className="lotto-ticket-time",
            ),
            html.Div(
                [html.Span(number, className="lotto-ticket-number") for number in numbers],
                className="lotto-ticket-numbers",
            ),
        ]
        if not printable:
            summary = print_summary or {}
            state = summary.get("status", "new")
            label = {"sent": "Previously sent to printer", "failed": "Previous send failed",
                     "uncertain": "Check previous printer send"}.get(state)
            if label:
                children.append(html.Span(label, className="lotto-print-badge is-{}".format(state)))
            sent_count = summary.get("sent_count", 0)
            if sent_count:
                children.append(html.P(
                    "{} send{} | {} | {} (Manila)".format(
                        sent_count, "" if sent_count == 1 else "s", summary["printer"],
                        summary["sent_at"].replace("T", " ").split("+")[0],
                    ),
                    className="lotto-print-history",
                ))
            children.append(
                html.Button(
                    "Reprint Ticket" if sent_count else "Print Ticket",
                    id={
                        "type": self.print_button_type,
                        "index": record.get("submission_id", ""),
                    },
                    n_clicks=0,
                    className="lotto-secondary-button lotto-ticket-print-button",
                )
            )
        return html.Article(children, className="lotto-ticket")

    def _load_ticket_cards(self, player_query=None):
        try:
            records = list(reversed(self.store.read()))
            summaries = self.print_store.summaries()
        except Exception as exc:
            return (
                [],
                str(exc),
                "lotto-message is-error",
            )
        query = str(player_query or "").strip().upper()
        if query:
            records = [
                record
                for record in records
                if query in str(record.get("player_number", "")).upper()
            ]
        if not records:
            empty_message = "No Lotto tickets have been submitted."
            status_message = "0 tickets"
            if query:
                empty_message = "No tickets found for {}.".format(query)
                status_message = "0 matching tickets"
            return (
                html.P(empty_message, className="lotto-empty-result"),
                status_message,
                "lotto-message",
            )
        return (
            [self._ticket(record, print_summary=summaries.get(record.get("submission_id"))) for record in records],
            "{:,} {}ticket{}".format(
                len(records),
                "matching " if query else "",
                "" if len(records) == 1 else "s",
            ),
            "lotto-message is-success",
        )

    def layout(self):
        cards, message, message_class = self._load_ticket_cards()
        return html.Div(
            [
                html.Link(rel="stylesheet", href="/assets/lotto/style.css"),
                dcc.Store(id=self.id("print-trigger")),
                dcc.Store(id=self.id("print-complete")),
                html.Main(
                    [
                        html.Header(
                            [
                                html.P("LOTTO", className="lotto-kicker"),
                                html.H1("Lotto Tickets", className="lotto-title"),
                                html.P(
                                    "Print Ticket opens the browser print dialog. Choose your USB or network printer there.",
                                    className="lotto-subtitle",
                                ),
                            ],
                            className="lotto-header",
                        ),
                        html.P("The browser cannot confirm printing or cancellation. Existing send history shows earlier direct-printer jobs only.", className="lotto-subtitle"),
                        html.Div(
                            [
                                dcc.Input(
                                    id=self.id("find-player"),
                                    type="text",
                                    placeholder="Enter player number",
                                    debounce=False,
                                    maxLength=50,
                                    n_submit=0,
                                    className="lotto-player-input",
                                ),
                                html.Button(
                                    "Find Player",
                                    id=self.id("find"),
                                    n_clicks=0,
                                    className="lotto-primary-button",
                                ),
                                html.Button(
                                    "Refresh Tickets",
                                    id=self.id("refresh"),
                                    n_clicks=0,
                                    className="lotto-secondary-button",
                                ),
                            ],
                            className="lotto-ticket-search",
                        ),
                        html.Div(
                            message,
                            id=self.id("message"),
                            className=message_class,
                            **{"aria-live": "polite"},
                        ),
                        html.Div(
                            cards,
                            id=self.id("ticket-list"),
                            className="lotto-ticket-list",
                        ),
                    ],
                    className="lotto-card lotto-results-card",
                ),
                html.Div(id=self.id("print-area"), className="lotto-print-area"),
            ],
            className="lotto-page lotto-tickets-page",
        )

    def register_callbacks(self):
        id_ = self.id

        @callback(
            Output(id_("ticket-list"), "children"),
            Output(id_("message"), "children"),
            Output(id_("message"), "className"),
            Input(id_("refresh"), "n_clicks"),
            Input(id_("find"), "n_clicks"),
            Input(id_("find-player"), "n_submit"),
            State(id_("find-player"), "value"),
            prevent_initial_call=True,
        )
        def refresh_tickets(refresh_clicks, find_clicks, find_submits, player_query):
            if not refresh_clicks and not find_clicks and not find_submits:
                raise PreventUpdate
            return self._load_ticket_cards(player_query)

        @callback(
            Output(id_("print-area"), "children"),
            Output(id_("print-trigger"), "data"),
            Input({"type": self.print_button_type, "index": ALL}, "n_clicks"),
            prevent_initial_call=True,
        )
        def prepare_ticket_for_print(print_clicks):
            if not any(print_clicks or []):
                raise PreventUpdate
            triggered = dash.ctx.triggered_id
            if not isinstance(triggered, dict):
                raise PreventUpdate
            # Rebuilding the list can trigger a new zero-click button while
            # other buttons still have clicks. Check the actual triggering one.
            clicked = next(
                (item.get("value") for item in dash.ctx.inputs_list[0]
                 if item.get("id") == triggered),
                0,
            )
            if not clicked:
                raise PreventUpdate
            submission_id = str(triggered.get("index", ""))
            record = next(
                (
                    item
                    for item in self.store.read()
                    if item.get("submission_id") == submission_id
                ),
                None,
            )
            if record is None:
                raise PreventUpdate
            return self._ticket(record, printable=True), str(uuid.uuid4())

        clientside_callback(
            """
            function(trigger) {
                if (!trigger) {
                    return window.dash_clientside.no_update;
                }
                // Allow the selected ticket to render before opening preview.
                window.setTimeout(function() { window.print(); }, 150);
                return trigger;
            }
            """,
            Output(id_("print-complete"), "data"),
            Input(id_("print-trigger"), "data"),
            prevent_initial_call=True,
        )


__all__ = ["LottoEntryPage", "LottoResultsPage", "LottoTicketsPage"]
