import logging
import sys
from pathlib import Path

import dash

PAGES_ROOT = Path(__file__).resolve().parent
if str(PAGES_ROOT) not in sys.path:
    sys.path.append(str(PAGES_ROOT))

from templates.raffle_entries import RaffleEntriesConfig, RaffleEntriesPage
from utils.login_handler import require_login, restricted_page
from utils.paths import OOC_ULTIMATE_PAY_DAY_RAFFLE_CHECKER


config = RaffleEntriesConfig(
    suffix="ooc-ultimate-pay-day-raffle-checker",
    page_path=OOC_ULTIMATE_PAY_DAY_RAFFLE_CHECKER,
    access_level=restricted_page[OOC_ULTIMATE_PAY_DAY_RAFFLE_CHECKER]["access_level"],
    entries_csv_path=(
        PAGES_ROOT.parent / "documents" / "ooc_ultimate_pay_day_raffle.csv"
    ),
    title="Merry Payday Raffle Checker",
    subtitle="Enter your patron ID to view your entitled raffle entries.",
    logo_src="/assets/ooc-ultimate-pay-day-raffle/logo.png",
    background_src="/assets/ooc-ultimate-pay-day-raffle/BG.jpg",
    brand_logo_src="/assets/ooc-ultimate-pay-day-raffle/ooc_logo.png",
    footer_src="/assets/ooc-ultimate-pay-day-raffle/footer.png",
    show_kicker=False,
    inclusion_date="Nov 15, 2026 8pm",
    logger=logging.getLogger("ooc-ultimate-pay-day-raffle-checker"),
)

dash.register_page(__name__, path=config.page_path, name=config.title)
require_login(__name__, access_level=config.access_level)

page = RaffleEntriesPage(config)
layout = page.layout
page.register_callbacks()
