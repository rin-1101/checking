import logging
import sys
from pathlib import Path

import dash

PAGES_ROOT = Path(__file__).resolve().parent
if str(PAGES_ROOT) not in sys.path:
    sys.path.append(str(PAGES_ROOT))

from templates.simple_raffle import SimpleRaffleConfig
from templates.limited_raffle import LimitedRafflePage
from utils.login_handler import require_login, restricted_page
from utils.paths import OOC_ULTIMATE_PAY_DAY_RAFFLE


config = SimpleRaffleConfig(
    suffix="ooc-ultimate-pay-day-raffle",
    page_path=OOC_ULTIMATE_PAY_DAY_RAFFLE,
    access_level=restricted_page[OOC_ULTIMATE_PAY_DAY_RAFFLE]["access_level"],
    entries_csv_path=(
        PAGES_ROOT.parent / "documents" / "ooc_ultimate_pay_day_raffle.csv"
    ),
    history_file_path=(
        PAGES_ROOT.parent / "JSON" / "raffle" / "winner_history"
        / "ooc_ultimate_pay_day_raffle-winners.json"
    ),
    event_name="ooc_ultimate_pay_day_raffle",
    title="Merry Payday Raffle",
    logo_src="/assets/ooc-ultimate-pay-day-raffle/logo.png",
    initial_message=(
        "Select 7 Minor Prize winners for each of the first two draws, "
        "then select 1 Grand Prize winner for the third draw. "
        "Minor Prize winners remain eligible for the Grand Prize."
    ),
    prize_enabled=True,
    prize_options_path=PAGES_ROOT.parent / "config" / "ooc_ultimate_pay_day_prize.yaml",
    export_enabled=True,
    logger=logging.getLogger("ooc-ultimate-pay-day-raffle"),
)

dash.register_page(__name__, path=config.page_path, name=config.title)
require_login(__name__, access_level=config.access_level)

page = LimitedRafflePage(config, prize_pool="OOC", selectable_draws=True)
layout = page.layout
page.register_callbacks()
