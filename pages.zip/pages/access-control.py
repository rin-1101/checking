"""Admin-only editor for the live username/role access list."""

import csv

import dash
from dash import Input, Output, State, callback, ctx, dash_table, dcc, html, no_update
from flask_login import current_user

from utils.get_users import load_users, save_users
from utils.login_handler import has_access, require_login, restricted_page, pages_name
from utils.paths import ACCESS_CONTROL


dash.register_page(__name__, path=ACCESS_CONTROL, name="Access Control")
require_login(__name__, access_level=["admin"])


def _roles():
    roles = {role for page in restricted_page.values() for role in page.get("access_level", [])}
    # Retain roles already in use, including those without configured report links.
    rows, _ = load_users()
    return sorted(roles | {row["role"] for row in rows})


def layout():
    if not has_access(current_user, ACCESS_CONTROL):
        return html.Div([html.H1("Access denied", className="title"),
                         dcc.Link("Return to Home", href="/home")], className="section")
    try:
        roles = _roles()
    except (OSError, ValueError, UnicodeError, csv.Error):
        roles = sorted({role for page in restricted_page.values() for role in page.get("access_level", [])})
    options = [{"label": role, "value": role} for role in roles]
    return html.Section([
        html.H1("Access Control", className="title"),
        html.P("Add users, edit usernames or roles, and remove rows with the × button. "
               "Click Save changes to apply your edits.", className="subtitle is-6"),
        html.P("Saved changes and direct edits to users.csv take effect on the next page visit or access check. "
               "Refresh Home to update report links. The built-in admin account always retains admin access.",
               className="notification is-info is-light"),
        dcc.Store(id="access-revision"),
        html.Div([
            html.Div([html.Label("Username", htmlFor="access-new-username", className="label"),
                      dcc.Input(id="access-new-username", placeholder="firstname.lastname", type="text",
                                className="input", style={"width": "100%"})], className="column"),
            html.Div([html.Label("Role", htmlFor="access-new-role", className="label"),
                      dcc.Dropdown(id="access-new-role", options=options, placeholder="Select a role", clearable=False)],
                     className="column"),
            html.Div(html.Button("Add user", id="access-add", className="button is-link is-light",
                                 style={"marginTop": "2rem"}), className="column is-narrow"),
        ], className="columns"),
        html.Div([
            html.Button("Save changes", id="access-save", className="button is-primary mr-3"),
            html.Button("Reload CSV", id="access-reload", className="button is-light"),
        ], className="buttons"),
        html.Div(id="access-message", role="status", **{"aria-live": "polite"}),
        dash_table.DataTable(
            id="access-table", data=[],
            columns=[{"name": "Username", "id": "username"},
                     {"name": "Role", "id": "role", "presentation": "dropdown"}],
            editable=True, row_deletable=True, filter_action="native", sort_action="native",
            page_size=20, page_action="native",
            dropdown={"role": {"options": options, "clearable": False}},
            style_table={"overflowX": "auto", "minHeight": "300px"},
            style_cell={"textAlign": "left", "padding": "10px", "fontFamily": "inherit", "minWidth": "160px"},
            style_header={"fontWeight": "bold", "backgroundColor": "#f5f5f5"},
            css=[{"selector": ".Select-menu-outer", "rule": "display: block !important;"}],
        ),
        html.Details([
            html.Summary("Reports available to each role", className="has-text-weight-semibold"),
            html.Table([
                html.Thead(html.Tr([html.Th("Role"), html.Th("Reports")])),
                html.Tbody([html.Tr([html.Td(role), html.Td(
                    ", ".join(pages_name.get(path, path) for path, info in restricted_page.items()
                              if role in info.get("access_level", [])) or "No configured reports"
                )]) for role in roles]),
            ], className="table is-striped is-fullwidth"),
        ], className="mt-5"),
    ], className="section", style={"maxWidth": "1100px", "margin": "0 auto", "whiteSpace": "normal"})


@callback(
    Output("access-table", "data"), Output("access-revision", "data"), Output("access-message", "children"),
    Input("access-reload", "n_clicks"), Input("access-add", "n_clicks"), Input("access-save", "n_clicks"),
    State("access-table", "data"), State("access-revision", "data"),
    State("access-new-username", "value"), State("access-new-role", "value"),
)
def update_access_list(reload_clicks, add_clicks, save_clicks, rows, revision, username, role):
    # Always check the current server-side role, including for forged callbacks or a demoted admin.
    if not has_access(current_user, ACCESS_CONTROL):
        return [], None, html.P("Access denied. Only administrators can manage users.", className="notification is-danger")
    try:
        action = ctx.triggered_id
        if action == "access-add":
            username = (username or "").strip().lower()
            if not revision:
                raise ValueError("Reload CSV before adding users.")
            if not username or not role:
                raise ValueError("Enter a username and select a role.")
            if username == "admin":
                raise ValueError("The built-in admin account already has admin access.")
            if any(str(row.get("username", "")).strip().lower() == username for row in rows or []):
                raise ValueError("That username is already listed. Edit the existing row instead.")
            if role not in _roles():
                raise ValueError("Select an existing role.")
            return [{"username": username, "role": role}] + (rows or []), no_update, html.P(
                "User added to your draft. Click Save changes to apply.", className="notification is-warning is-light")
        if action == "access-save":
            rows, revision = save_users(rows or [], revision, _roles())
            message = "Saved {} users. Access changes are now active.".format(len(rows))
        else:
            rows, revision = load_users()
            message = "Loaded {} users. Edits remain a draft until you save.".format(len(rows))
        return rows, revision, html.P(message, className="notification is-success is-light")
    except (OSError, ValueError, UnicodeError, csv.Error) as error:
        return no_update, no_update, html.P(str(error), className="notification is-danger is-light")
