"""CSV/Excel preview and CSV upload page for Hive-backed HDFS locations."""

import base64
import binascii
import posixpath
import re
import sys
from io import BytesIO, StringIO

import dash
import pandas as pd
import requests
from dash import Input, Output, State, callback, dash_table, dcc, html
from dash.exceptions import PreventUpdate

from utils.paths import HDFS_UPLOADER


HDFS_ROOT = (
    r"\\ominfstdpsd10001p-fs.int.okadamanila.com\Casino\Strategic Marketing"
    r"\Database Admin\ETL\Applications\okada\okada\hdfs"
)
if HDFS_ROOT not in sys.path:
    sys.path.insert(0, HDFS_ROOT)

from hdfs import InsecureClient


MAX_UPLOAD_BYTES = 10 * 1024 * 1024
PREVIEW_ROWS = 100
HDFS_URL = "http://omdmtdbsd15002p:9870"
HDFS_USER = "hdfs"

# Add future tables here. Partition columns may be supplied when known.
HIVE_TABLES = {
    "dwd.dwd_tg_game_family": {
        "hdfs_path": "/user/products/tg_game_family",
        "partitions": [],
    },
}


class HDFS(object):
    """Upload pandas DataFrames directly as UTF-8 CSV files."""

    def __init__(
        self,
        hdfs_directory,
        partitions=None,
        verify_ssl=False,
        hdfs_url=HDFS_URL,
        user=HDFS_USER,
    ):
        self.hdfs_directory = str(hdfs_directory).rstrip("/")
        self.partitions = list(partitions or [])
        session = requests.Session()
        session.verify = verify_ssl
        self.client = InsecureClient(hdfs_url, user=user, session=session)

    @staticmethod
    def _safe_path_value(value):
        text = str(value).strip()
        if not text:
            raise ValueError("Partition values cannot be blank.")
        return re.sub(r"[^A-Za-z0-9._=-]", "_", text)

    def _partition_path(self, values):
        return "/".join(
            "{}={}".format(column, self._safe_path_value(value))
            for column, value in zip(self.partitions, values)
        )

    def upload_dataframe(self, dataframe, filename="upload.csv", overwrite=True):
        if not isinstance(dataframe, pd.DataFrame):
            raise TypeError("dataframe must be a pandas DataFrame.")
        if dataframe.empty:
            raise ValueError("The uploaded data has no rows.")

        missing = [column for column in self.partitions if column not in dataframe.columns]
        if missing:
            raise ValueError(
                "Missing partition column(s): {}".format(", ".join(missing))
            )

        safe_filename = re.sub(r"[^A-Za-z0-9._-]", "_", filename)
        if not safe_filename.lower().endswith(".csv"):
            safe_filename += ".csv"

        uploaded_paths = []
        if not self.partitions:
            groups = [((), dataframe)]
        else:
            group_key = self.partitions[0] if len(self.partitions) == 1 else self.partitions
            groups = dataframe.groupby(group_key, dropna=False, sort=False)

        for values, partition_data in groups:
            values = values if isinstance(values, tuple) else (values,)
            directory = self.hdfs_directory
            if self.partitions:
                directory = posixpath.join(directory, self._partition_path(values))

            self.client.makedirs(directory)
            remote_path = posixpath.join(directory, safe_filename)
            csv_bytes = partition_data.to_csv(index=False).encode("utf-8")
            self.client.write(
                remote_path,
                data=csv_bytes,
                overwrite=overwrite,
                encoding=None,
            )
            uploaded_paths.append(remote_path)

        return uploaded_paths


dash.register_page(__name__, path=HDFS_UPLOADER, name="HDFS Uploader")


def layout():
    return html.Div(
        className="container",
        children=[
            html.H1("HDFS File Uploader", className="title has-text-centered mb-2"),
            html.P(
                "Preview CSV or Excel data, then upload it to HDFS as UTF-8 CSV.",
                className="subtitle is-6 has-text-centered has-text-grey mb-5",
            ),
            html.Div(
                className="box",
                children=[
                    html.Label("Hive table", className="label"),
                    dcc.Dropdown(
                        id="hdfs-hive-table",
                        options=[
                            {
                                "label": "{} ({})".format(
                                    table, config["hdfs_path"]
                                ),
                                "value": table,
                            }
                            for table, config in HIVE_TABLES.items()
                        ],
                        placeholder="Select the Hive table to update",
                        clearable=False,
                        className="mb-4",
                    ),
                    html.Label("CSV or Excel file", className="label"),
                    dcc.Upload(
                        id="hdfs-file-upload",
                        accept=".csv,.xlsx,.xls,text/csv,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        multiple=False,
                        children=html.Div(
                            [
                                html.Span("Drag and drop a file here, or "),
                                html.Strong("choose a file"),
                            ],
                            className="has-text-centered",
                        ),
                        style={
                            "width": "100%",
                            "padding": "2rem",
                            "borderWidth": "2px",
                            "borderStyle": "dashed",
                            "borderColor": "#b5b5b5",
                            "borderRadius": "6px",
                            "cursor": "pointer",
                            "backgroundColor": "#fafafa",
                        },
                    ),
                    html.P(
                        "CSV, XLSX, and XLS files up to 10 MB are accepted. Excel uses the first worksheet.",
                        className="help mt-2",
                    ),
                    html.Div(id="hdfs-preview-status", className="mt-4", role="status"),
                    html.Button(
                        "Upload to HDFS",
                        id="hdfs-submit-upload",
                        n_clicks=0,
                        disabled=True,
                        className="button is-primary mt-3",
                    ),
                    html.Div(id="hdfs-write-status", className="mt-4", role="status"),
                ],
            ),
            dcc.Store(id="hdfs-normalized-csv"),
            dcc.Loading(html.Div(id="hdfs-upload-preview"), type="circle"),
        ],
    )


def _decode_upload(contents):
    if not contents or "," not in contents:
        raise ValueError("The uploaded file could not be read.")
    try:
        raw = base64.b64decode(contents.split(",", 1)[1], validate=True)
    except (binascii.Error, ValueError) as exc:
        raise ValueError("The uploaded file is not valid upload data.") from exc
    if not raw:
        raise ValueError("The uploaded file is empty.")
    if len(raw) > MAX_UPLOAD_BYTES:
        raise ValueError("The file exceeds the 10 MB upload limit.")
    return raw


def _read_file(raw, extension):
    if extension == ".csv":
        try:
            dataframe = pd.read_csv(BytesIO(raw), dtype=str, keep_default_na=False)
        except UnicodeDecodeError:
            dataframe = pd.read_csv(
                BytesIO(raw), dtype=str, keep_default_na=False, encoding="cp1252"
            )
        sheet_name = None
    else:
        with pd.ExcelFile(BytesIO(raw)) as workbook:
            if not workbook.sheet_names:
                raise ValueError("The Excel workbook contains no worksheets.")
            sheet_name = workbook.sheet_names[0]
            dataframe = pd.read_excel(
                workbook, sheet_name=sheet_name, dtype=str, keep_default_na=False
            )

    if not len(dataframe.columns):
        raise ValueError("The file contains no columns.")
    buffer = StringIO()
    dataframe.to_csv(buffer, index=False)
    return buffer.getvalue(), sheet_name


def _preview_table(dataframe):
    preview = dataframe.head(PREVIEW_ROWS)
    return dash_table.DataTable(
        data=preview.to_dict("records"),
        columns=[{"name": column, "id": column} for column in preview.columns],
        page_size=10,
        sort_action="native",
        filter_action="native",
        style_table={"overflowX": "auto"},
        style_header={
            "backgroundColor": "#2c3e50",
            "color": "white",
            "fontWeight": "bold",
        },
        style_cell={
            "padding": "8px",
            "textAlign": "left",
            "minWidth": "120px",
            "maxWidth": "320px",
            "whiteSpace": "normal",
        },
    )


@callback(
    Output("hdfs-preview-status", "children"),
    Output("hdfs-upload-preview", "children"),
    Output("hdfs-normalized-csv", "data"),
    Output("hdfs-submit-upload", "disabled"),
    Input("hdfs-file-upload", "contents"),
    State("hdfs-file-upload", "filename"),
    State("hdfs-hive-table", "value"),
    prevent_initial_call=True,
)
def preview_file(contents, filename, hive_table):
    if not contents:
        raise PreventUpdate
    if hive_table not in HIVE_TABLES:
        return html.P("Select a Hive table first.", className="notification is-warning"), "", None, True

    safe_filename = str(filename or "uploaded file")
    extension = "." + safe_filename.rsplit(".", 1)[-1].lower() if "." in safe_filename else ""
    if extension not in {".csv", ".xlsx", ".xls"}:
        return html.P("Please upload a CSV, XLSX, or XLS file.", className="notification is-warning"), "", None, True

    try:
        raw = _decode_upload(contents)
        csv_text, sheet_name = _read_file(raw, extension)
        dataframe = pd.read_csv(StringIO(csv_text), dtype=str, keep_default_na=False)
    except Exception as exc:
        return html.P("Unable to process the file: {}".format(exc), className="notification is-danger"), "", None, True

    config = HIVE_TABLES[hive_table]
    status = html.Div(
        className="notification is-info",
        children=[
            html.Strong(safe_filename),
            html.Span(" converted to CSV: {:,} row(s), {:,} column(s). ".format(len(dataframe), len(dataframe.columns))),
            html.Span("Worksheet: {}. ".format(sheet_name)) if sheet_name else None,
            html.Br(),
            html.Span("Target: {} | {}".format(hive_table, config["hdfs_path"])),
        ],
    )
    return status, html.Div([html.H2("Preview", className="title is-5"), _preview_table(dataframe)], className="box"), {"csv": csv_text, "filename": safe_filename, "hive_table": hive_table}, False


@callback(
    Output("hdfs-write-status", "children"),
    Input("hdfs-submit-upload", "n_clicks"),
    State("hdfs-normalized-csv", "data"),
    State("hdfs-hive-table", "value"),
    prevent_initial_call=True,
)
def upload_to_hdfs(n_clicks, stored_file, hive_table):
    if not n_clicks:
        raise PreventUpdate
    if not stored_file or hive_table not in HIVE_TABLES:
        return html.P("Preview a file and select a Hive table first.", className="notification is-warning")
    if stored_file.get("hive_table") != hive_table:
        return html.P(
            "The selected Hive table changed. Upload the file again to refresh its preview.",
            className="notification is-warning",
        )

    try:
        dataframe = pd.read_csv(
            StringIO(stored_file["csv"]), dtype=str, keep_default_na=False
        )
        config = HIVE_TABLES[hive_table]
        stem = stored_file["filename"].rsplit(".", 1)[0]
        loader = HDFS(
            hdfs_directory=config["hdfs_path"],
            partitions=config.get("partitions", []),
        )
        uploaded_paths = loader.upload_dataframe(
            dataframe, filename="{}.csv".format(stem), overwrite=True
        )
    except Exception as exc:
        return html.P("HDFS upload failed: {}".format(exc), className="notification is-danger")

    return html.Div(
        className="notification is-success",
        children=[
            html.Strong("Upload complete. "),
            html.Span("Written to {}".format(", ".join(uploaded_paths))),
        ],
    )
