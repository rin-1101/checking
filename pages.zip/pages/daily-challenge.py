"""Daily Challenge TP progress page."""

import math
import re
import sys
from datetime import datetime, timedelta
from functools import lru_cache
from pathlib import Path
from urllib.parse import quote

import dash
from dash import Input, Output, State, callback, dcc, html
from openpyxl import load_workbook

from utils.login_handler import require_login, restricted_page


ROOT2 = (
    r"\\ominfstdpsd10001p-fs.int.okadamanila.com\Casino\Strategic Marketing"
    r"\Database Admin\ETL\Applications"
)
OKADA_ROOT = str(Path(ROOT2) / "okada")
if OKADA_ROOT not in sys.path:
    sys.path.append(OKADA_ROOT)

PAGE_PATH = "/daily-challenge"
MASTERLIST_PATH = Path(
    ROOT2
) / "Data Science" / "Jobs" / "Offer Whitelist" / "Final" / "20261026" / (
    "Daily Challenge Masterlist.xlsx"
)
GAMING_DAY_START_HOUR = 6
DATETIME_FORMAT = "%Y-%m-%d %H:%M:%S"


dash.register_page(
    __name__,
    path=PAGE_PATH,
    name="Daily Challenge",
)
require_login(__name__, access_level=restricted_page[PAGE_PATH]["access_level"])

COLORS = {
    "navy": "#171214",
    "blue": "#86145f",
    "cyan": "#cfc7a5",
    "green": "#6f7a4a",
    "amber": "#b8aa78",
    "muted": "#6e6468",
    "surface": "#fffdf7",
    "background": "#e5dfc6",
    "border": "#c9c09d",
}

OKADA_MARK_SVG = """
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300">
  <g fill="#86145f" opacity="0.055">
    <circle cx="150" cy="48" r="42"/>
    <circle cx="76" cy="91" r="42"/>
    <circle cx="224" cy="91" r="42"/>
    <circle cx="76" cy="177" r="42"/>
    <circle cx="224" cy="177" r="42"/>
    <circle cx="150" cy="220" r="42"/>
    <circle cx="150" cy="134" r="42"/>
  </g>
</svg>
""".strip()
OKADA_MARK_DATA_URL = "data:image/svg+xml,{}".format(quote(OKADA_MARK_SVG))


def _format_om(value):
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        digits = str(int(value))
    else:
        normalized_value = str(value or "").strip()
        digits = re.sub(r"\D", "", normalized_value)
    return "OM{}".format(digits.zfill(9)) if digits else ""


@lru_cache(maxsize=2)
def _load_masterlist(_modified_time):
    workbook = load_workbook(MASTERLIST_PATH, read_only=True, data_only=True)
    try:
        worksheet = workbook.active
        rows = worksheet.iter_rows(values_only=True)
        headers = next(rows, ())
        normalized_headers = [str(header or "").strip().casefold() for header in headers]
        required_headers = [
            "universalplayerid",
            "target 1", "reward 1", "target 2", "reward 2",
            "target 3", "reward 3", "target 4", "reward 4",
            "target 5", "reward 5",
        ]
        try:
            indexes = {
                header: normalized_headers.index(header)
                for header in required_headers
            }
        except ValueError as exc:
            raise ValueError("Masterlist is missing a required reward column.") from exc

        members = {}
        for row in rows:
            om_number = _format_om(row[indexes["universalplayerid"]])
            if not om_number:
                continue
            milestones = tuple(
                (
                    int(row[indexes["target {}".format(index)]] or 0),
                    int(row[indexes["reward {}".format(index)]] or 0),
                )
                for index in range(1, 6)
            )
            members[om_number] = milestones
        return members
    finally:
        workbook.close()


def _masterlist():
    return _load_masterlist(MASTERLIST_PATH.stat().st_mtime_ns)


def _current_gaming_day_window(now=None):
    current_time = now or datetime.now()
    cutoff = current_time.replace(
        hour=GAMING_DAY_START_HOUR,
        minute=0,
        second=0,
        microsecond=0,
    )
    window_start = cutoff if current_time >= cutoff else cutoff - timedelta(days=1)
    window_end = window_start + timedelta(days=1)
    return (
        window_start.strftime(DATETIME_FORMAT),
        window_end.strftime(DATETIME_FORMAT),
    )


def _get_tier_points(om_number):
    from okada import SQL

    loader = SQL("halo").get_loader()
    try:
        query = """
            SELECT SUM(tp.TierPoint) AS Sum_TP
            FROM [ENGAGEDB].[dbo].[UC_PL_Rating] r
            LEFT JOIN [ENGAGEDB].[dbo].[UC_PL_Player] p
                ON r.PlayerID = p.PlayerID
            LEFT JOIN [ENGAGEDB].[dbo].[UC_PL_TierPointDetailActual] tp
                ON r.RatingID = tp.RatingID
            WHERE r.TransactionDateTime >= '2026-10-20 06:00:00'
              AND r.TransactionDateTime < '2026-10-21 06:00:00'
              AND LTRIM(RTRIM(p.UniversalPlayerID)) = '{om_number}'
        """.format(
            # start=campaign_start,
            # end=campaign_end,
            om_number=om_number,
        )
        result = loader.load_data(query)
        if result.empty or result.iloc[0]["Sum_TP"] is None:
            return 0
        return max(math.ceil(float(result.iloc[0]["Sum_TP"])), 0)
    finally:
        clean_up = getattr(loader, "clean_up", None)
        if callable(clean_up):
            clean_up()


def _incremental_reward(milestones, target_index):
    if target_index < 1:
        return 0
    current_reward = milestones[target_index - 1][1]
    previous_reward = milestones[target_index - 2][1] if target_index > 1 else 0
    return max(current_reward - previous_reward, 0)


def _milestone_timeline(milestones, points):
    node_positions = (10, 30, 50, 70, 90)
    targets = [max(milestone[0], 0) for milestone in milestones]
    normalized_points = max(points, 0)

    if normalized_points <= targets[0]:
        progress = (normalized_points / max(targets[0], 1)) * node_positions[0]
    elif normalized_points >= targets[-1]:
        progress = 100
    else:
        progress = node_positions[0]
        for index in range(1, len(targets)):
            if normalized_points <= targets[index]:
                previous_target = targets[index - 1]
                target_span = max(targets[index] - previous_target, 1)
                interval_progress = (
                    (normalized_points - previous_target) / target_span
                )
                progress = node_positions[index - 1] + (
                    interval_progress
                    * (node_positions[index] - node_positions[index - 1])
                )
                break
    circles = []
    for index, (target, _reward) in enumerate(milestones, start=1):
        reached = points >= target
        next_target = not reached and all(
            points >= item[0] for item in milestones[: index - 1]
        )
        state = " is-reached" if reached else " is-next" if next_target else ""
        circles.append(
            html.Div(
                [
                    html.Div(
                        [
                            html.Div("TARGET {}".format(index), className="dc-target-label"),
                            html.Div("{:,}".format(target), className="dc-target-value"),
                            html.Div("TP", className="dc-target-unit"),
                        ],
                        className="dc-circle",
                    ),
                    html.Div(
                        [
                            html.Div("REWARD", className="dc-reward-label"),
                            html.Div(
                                "+{:,}".format(_incremental_reward(milestones, index)),
                                className="dc-reward-value",
                            ),
                        ],
                        className="dc-node-reward",
                    ),
                    html.Span(
                        "Reached" if reached else "Next target" if next_target else "Upcoming",
                        className="dc-sr-only",
                    ),
                ],
                className="dc-node" + state,
            )
        )
    return html.Div(
        [
            html.Div(
                html.Div(
                    className="dc-fill",
                    style={"width": "{:.2f}%".format(progress)},
                ),
                className="dc-track",
                **{"aria-hidden": "true"},
            ),
            html.Div(circles, className="dc-nodes"),
        ],
        className="dc-timeline",
    )


def _summary(milestones, points):
    reached_targets = [
        index
        for index, (target, _reward) in enumerate(milestones, start=1)
        if points >= target
    ]
    max_target = reached_targets[-1] if reached_targets else 0
    total_reward = milestones[max_target - 1][1] if max_target else 0
    next_target = milestones[max_target][0] if max_target < len(milestones) else None

    if next_target is None:
        next_target_text = "All targets complete"
        remaining_text = "0 TP"
        status = "Excellent work — every daily target has been reached."
    else:
        points_needed = max(next_target - points, 0)
        next_target_text = "{:,} TP".format(next_target)
        remaining_text = "{:,} TP".format(points_needed)
        status = "{:,} more Tier Points to unlock Target {}.".format(points_needed, max_target + 1)

    return max_target, total_reward, next_target_text, remaining_text, status


def layout():
    return html.Div(
        id="daily-challenge-page",
        className="daily-challenge-page",
        style={
            "backgroundColor": COLORS["background"],
            "backgroundImage": (
                "url(\"{}\"), "
                "radial-gradient(circle at 15% 12%, rgba(134,20,95,0.10), transparent 34%), "
                "radial-gradient(circle at 88% 85%, rgba(212,175,55,0.12), transparent 40%), "
                "linear-gradient(145deg, #f4efe0 0%, #e5dfc6 52%, #d8d0af 100%)"
            ).format(OKADA_MARK_DATA_URL),
            "backgroundPosition": "center, center, center, center",
            "backgroundSize": "82vmin 82vmin, auto, auto, cover",
            "backgroundRepeat": "no-repeat",
        },
        children=[
            html.Link(rel="stylesheet", href="/assets/daily-challenge/style.css"),
            html.Main(
                id="daily-challenge-shell",
                className="dc-shell",
                children=[
                    html.Header(
                        [
                            html.H1("Daily Challenge", className="dc-title"),
                            html.Span("PLAYER REWARDS", className="dc-kicker"),
                        ],
                        className="dc-header",
                    ),
                    html.Section(
                        className="dc-member-card",
                        children=[
                            html.Div(
                                html.Label(
                                    "MEMBER",
                                    htmlFor="daily-challenge-player-id",
                                    className="dc-kicker dc-member-label",
                                ),
                                className="dc-member-heading",
                            ),
                            html.Div(
                                [
                                    dcc.Input(
                                        id="daily-challenge-player-id",
                                        value="",
                                        type="text",
                                        placeholder="Enter OM Number",
                                        n_submit=0,
                                        autoComplete="off",
                                        debounce=False,
                                        className="dc-input",
                                    ),
                                    html.Button(
                                        "Check",
                                        id="daily-challenge-check",
                                        n_clicks=0,
                                        className="dc-check",
                                    ),
                                ],
                                className="dc-search-row",
                            ),
                            html.Div(
                                [
                                    html.Div(
                                        id="daily-challenge-lookup-message",
                                        className="dc-message",
                                        role="status",
                                    ),
                                    html.Div(
                                        html.Button(
                                            "Check Another Member",
                                            id="daily-challenge-reset",
                                            n_clicks=0,
                                            className="dc-reset",
                                        ),
                                        id="daily-challenge-reset-container",
                                        style={"display": "none"},
                                    ),
                                ],
                                className="dc-member-footer",
                            ),
                        ],
                    ),
                    dcc.Loading(
                        type="circle",
                        color=COLORS["blue"],
                        children=html.Section(
                            id="daily-challenge-tracker",
                            className="dc-tracker",
                            style={"display": "none"},
                            **{"aria-label": "Daily Challenge progress"},
                            children=[
                                html.Div(
                                    [
                                        html.Div(
                                            [
                                                html.Div(id="daily-challenge-points-label", className="dc-earned"),
                                                html.Span("Earned", className="dc-progress-caption"),
                                            ],
                                            className="dc-progress-metric",
                                        ),
                                        html.Div(
                                            [
                                                html.Div(
                                                    "UPCOMING REWARD",
                                                    id="daily-challenge-upcoming-label",
                                                    className="dc-upcoming-label",
                                                ),
                                                html.Div(
                                                    id="daily-challenge-upcoming-reward",
                                                    className="dc-upcoming-value",
                                                ),
                                                html.Div(
                                                    "FREEPLAY",
                                                    id="daily-challenge-upcoming-unit",
                                                    className="dc-upcoming-unit",
                                                ),
                                            ],
                                            className="dc-upcoming",
                                        ),
                                        html.Div(
                                            [
                                                html.Strong(id="daily-challenge-percent"),
                                                html.Span("to next reward", className="dc-progress-caption"),
                                            ],
                                            id="daily-challenge-remaining",
                                            className="dc-remaining",
                                        ),
                                    ],
                                    className="dc-progress-heading",
                                ),
                                html.Div(
                                    id="daily-challenge-milestones",
                                    className="dc-timeline-scroll",
                                    role="region",
                                    tabIndex="0",
                                    **{"aria-label": "Five daily targets and rewards"},
                                ),
                                html.Div(
                                    [
                                        html.Span(["Reached: ", html.Strong(id="daily-challenge-max-target")]),
                                        html.Span(["Next: ", html.Strong(id="daily-challenge-next-target")]),
                                        html.Span(["Total earned reward: ", html.Strong(id="daily-challenge-reward")]),
                                    ],
                                    className="dc-details",
                                ),
                                html.Div(id="daily-challenge-status", className="dc-sr-only", role="status"),
                            ],
                        ),
                    ),
                    dcc.Interval(
                        id="daily-challenge-auto-reset",
                        interval=10 * 1000,
                        n_intervals=0,
                        disabled=True,
                    ),
                ],
            ),
        ],
    )


@callback(
    Output("nav-main", "style"),
    Input("url", "pathname"),
)
def hide_daily_challenge_navigation(pathname):
    if pathname != PAGE_PATH:
        return {}
    return {"display": "none"}


@callback(
    Output("daily-challenge-max-target", "children"),
    Output("daily-challenge-next-target", "children"),
    Output("daily-challenge-percent", "children"),
    Output("daily-challenge-reward", "children"),
    Output("daily-challenge-status", "children"),
    Output("daily-challenge-points-label", "children"),
    Output("daily-challenge-tracker", "style"),
    Output("daily-challenge-lookup-message", "children"),
    Output("daily-challenge-milestones", "children"),
    Output("daily-challenge-player-id", "value"),
    Output("daily-challenge-auto-reset", "disabled"),
    Output("daily-challenge-reset-container", "style"),
    Output("daily-challenge-shell", "className"),
    Output("daily-challenge-upcoming-reward", "children"),
    Output("daily-challenge-upcoming-label", "children"),
    Output("daily-challenge-remaining", "style"),
    Output("daily-challenge-upcoming-unit", "style"),
    Input("daily-challenge-check", "n_clicks"),
    Input("daily-challenge-player-id", "n_submit"),
    Input("daily-challenge-reset", "n_clicks"),
    Input("daily-challenge-auto-reset", "n_intervals"),
    State("daily-challenge-player-id", "value"),
    prevent_initial_call=True,
)
def update_daily_challenge(
    _check_clicks, _input_submits, _reset_clicks, _reset_intervals, player_id
):
    triggered_id = dash.callback_context.triggered[0]["prop_id"].split(".")[0]

    def empty_progress(message="", value=dash.no_update):
        return (
            "", "", "", "", "", "",
            {"display": "none"}, message, [], value, True,
            {"display": "none"}, "dc-shell", "", "UPCOMING REWARD", {},
            {"display": "none"},
        )

    if triggered_id in {"daily-challenge-reset", "daily-challenge-auto-reset"}:
        return empty_progress(value="")

    formatted_player_id = _format_om(player_id)
    if not formatted_player_id:
        return empty_progress("Please enter a valid OM Number.")

    try:
        milestones = _masterlist().get(formatted_player_id)
    except (OSError, ValueError):
        return empty_progress("The Daily Challenge masterlist is currently unavailable.")

    if milestones is None:
        return empty_progress("This OM Number is not included in the Daily Challenge.")

    try:
        normalized_points = _get_tier_points(formatted_player_id)
    except Exception:
        return empty_progress("We could not retrieve the current Tier Points. Please try again.")

    max_target, reward, next_target, remaining, status = _summary(
        milestones, normalized_points
    )
    complete = max_target == len(milestones)
    upcoming_reward = (
        "All targets complete" if complete else "+{:,}".format(
            _incremental_reward(milestones, max_target + 1)
        )
    )
    return (
        "Target {}".format(max_target) if max_target else "Not reached",
        next_target,
        remaining,
        "{:,}".format(reward),
        status,
        "{:,} TP".format(normalized_points),
        {"display": "block"},
        "",
        _milestone_timeline(milestones, normalized_points),
        formatted_player_id,
        False,
        {"display": "block"},
        "dc-shell is-results",
        upcoming_reward,
        "DAILY CHALLENGE COMPLETE" if complete else "UPCOMING REWARD",
        {"display": "none"} if complete else {},
        {"display": "none"} if complete else {},
    )
